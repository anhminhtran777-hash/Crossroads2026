/**
 * The conversation lives outside React so it survives moving between screens, and so an answer that is
 * still being worked on can finish (and its approval cards appear) even if the user opened another page.
 */
import { useSyncExternalStore } from "react";
import type { Authorization } from "./authorizations";

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  text: string;
  /** Approval cards that belong to this message. */
  auths?: Authorization[];
  /** Names of attached files (display only). */
  files?: string[];
  /** Sent to the AI but not shown (e.g. the result of an authorization). */
  hidden?: boolean;
  /** What the AI sees instead of `text` (e.g. the text plus the result of reading an attached document). */
  aiText?: string;
};

type Snapshot = { owner: string | null; messages: ChatMessage[]; busy: boolean; briefed: boolean };
let snap: Snapshot = { owner: null, messages: [], busy: false, briefed: false };
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());
const set = (patch: Partial<Snapshot>) => {
  snap = { ...snap, ...patch };
  emit();
};
let n = 0;
export const messageId = () => `m-${Date.now().toString(36)}-${(n++).toString(36)}`;

export const chatStore = {
  get: () => snap,
  subscribe: (l: () => void) => {
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  },
  /** Starts a fresh conversation when a different person signs in. */
  claim(owner: string) {
    if (snap.owner !== owner) set({ owner, messages: [], busy: false, briefed: false });
  },
  markBriefed: () => set({ briefed: true }),
  setBusy: (busy: boolean) => set({ busy }),
  push(m: Omit<ChatMessage, "id"> & { id?: string }) {
    const msg: ChatMessage = { ...m, id: m.id ?? messageId() };
    set({ messages: [...snap.messages, msg] });
    return msg.id;
  },
  /** Gives the most recent user message the text the AI should see instead of what is displayed. */
  patchMessageAi(aiText: string) {
    const i = snap.messages.map((m) => m.role === "user" && !m.hidden).lastIndexOf(true);
    if (i < 0) return;
    set({ messages: snap.messages.map((m, k) => (k === i ? { ...m, aiText } : m)) });
  },
  /** Changes one approval card wherever it is. Returns the card as it was before. */
  patchAuth(authId: string, patch: Partial<Authorization>): Authorization | undefined {
    let before: Authorization | undefined;
    set({
      messages: snap.messages.map((m) =>
        m.auths?.some((a) => a.id === authId)
          ? { ...m, auths: m.auths.map((a) => (a.id === authId ? ((before = a), { ...a, ...patch }) : a)) }
          : m,
      ),
    });
    return before;
  },
  findAuth: (authId: string) => snap.messages.flatMap((m) => m.auths ?? []).find((a) => a.id === authId),
  /** Cards still waiting for a decision. */
  pendingAuths: () => snap.messages.flatMap((m) => m.auths ?? []).filter((a) => a.status === "pending"),
};

export const useChat = () => useSyncExternalStore(chatStore.subscribe, chatStore.get, chatStore.get);
