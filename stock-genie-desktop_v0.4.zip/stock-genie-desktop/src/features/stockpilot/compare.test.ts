import { describe, expect, it } from "vitest";
import { initialState } from "./model";
import { compareRequest, exampleDocs, suggestOrder } from "./compare";
import { proposeCostChanges, proposeProducts } from "./proposals";

const S = initialState;
const ex = Object.fromEntries(exampleDocs(S).map((e) => [e.id, e]));
const run = (id: string) => compareRequest(S, S.orders.find((o) => o.id === ex[id]!.orderId)!, ex[id]!.doc);

describe("request vs paperwork", () => {
  it("finds short and missing items", () => {
    const c = run("ex-short");
    expect(c.counts.short).toBe(1);
    expect(c.counts.missing).toBe(1);
    expect(c.complete).toBe(false);
  });
  it("finds price rises and unrequested new products", () => {
    const c = run("ex-price");
    expect(c.counts.priceFlags).toBe(1);
    expect(c.rows.some((r) => r.isNew)).toBe(true);
  });
  it("passes a perfect delivery", () => expect(run("ex-ok").complete).toBe(true));
  it("picks the matching request automatically", () => expect(suggestOrder(S, ex["ex-short"]!.doc)?.id).toBe(ex["ex-short"]!.orderId));
});

describe("catalogue proposals from paperwork", () => {
  it("proposes an auto-priced new product and a cost update", () => {
    const np = proposeProducts(S, ex["ex-price"]!.doc, 1);
    expect(np).toHaveLength(1);
    expect(np[0]!.draft.price).toBeGreaterThan(np[0]!.draft.cost);
    expect(proposeCostChanges(S, ex["ex-price"]!.doc, 1)).toHaveLength(1);
    expect(proposeProducts(S, ex["ex-price"]!.doc, 0)).toHaveLength(0); // foreign currency needs a rate first
  });
});
