/**
 * Request-vs-paperwork comparison. Pure and offline: given a purchase request and a delivery note or
 * invoice (scanned, saved, or from the Documents list) it says what arrived, what is missing or short,
 * what was not requested, and where prices differ from what you normally pay.
 */
import type { Order, StoreDocument, StoreState } from "./model";
import { matchProduct, sameParty, unitCost, unitQty, type ScanLine, type ScanRecord } from "./scan-checks";

export type CompareDoc = {
  label: string;
  kind: string;
  number: string | null;
  issuer: string | null;
  currency: string | null;
  total: number | null;
  lines: ScanLine[];
};
export type RowStatus = "ok" | "short" | "over" | "missing" | "extra";
export type CompareRow = {
  key: string;
  name: string;
  productId: string | undefined;
  requested: number;
  received: number;
  status: RowStatus;
  /** Billed price per single unit, when the document shows one. */
  unitPrice: number | null;
  expectedCost: number | null;
  priceDiffPct: number | null;
  /** An extra line that matches no product in the inventory at all. */
  isNew: boolean;
  note: string;
};
export type Comparison = {
  order: Order;
  doc: CompareDoc;
  rows: CompareRow[];
  counts: { ok: number; short: number; over: number; missing: number; extra: number; priceFlags: number };
  requestedValue: number;
  documentValue: number | null;
  issues: string[];
  complete: boolean;
};

const PRICE_TOLERANCE = 0.05;
const r2 = (n: number) => Math.round(n * 100) / 100;

export function docFromScan(s: ScanRecord): CompareDoc {
  return { label: `${s.documentType}${s.number ? ` ${s.number}` : ""}`, kind: s.documentType, number: s.number, issuer: s.issuer, currency: s.currency, total: s.total, lines: s.lines };
}
export function docFromStoreDocument(d: StoreDocument, state: StoreState): CompareDoc {
  return {
    label: `${d.kind} ${d.number ?? d.reference}`,
    kind: d.kind,
    number: d.number ?? d.reference,
    issuer: d.party,
    currency: "USD",
    total: d.total,
    lines: d.lines.map((l) => ({
      description: l.name,
      quantity: l.quantity,
      unitPrice: l.unit,
      amount: r2(l.quantity * l.unit),
      productId: l.productId ?? matchProduct(state.products, l.name)?.id,
    })),
  };
}

export function compareRequest(state: StoreState, order: Order, doc: CompareDoc): Comparison {
  const lines = doc.lines.map((l) => ({ ...l, productId: l.productId ?? matchProduct(state.products, l.description)?.id }));
  const dollars = !doc.currency || doc.currency === "USD";
  const rows: CompareRow[] = [];
  const claimed = new Set<number>();

  for (const ol of order.lines) {
    const p = state.products.find((x) => x.id === ol.productId);
    const name = p ? `${p.name}${p.size ? ` (${p.size})` : ""}` : ol.productId;
    const hits = lines.map((l, i) => ({ l, i })).filter(({ l }) => l.productId === ol.productId);
    hits.forEach(({ i }) => claimed.add(i));
    const received = hits.reduce((n, { l }) => n + (unitQty(l) ?? 0), 0);
    const unknownQty = hits.length > 0 && hits.every(({ l }) => l.quantity === null);
    const prices = hits.map(({ l }) => unitCost(l)).filter((x): x is number => x !== null);
    const unitPrice = prices.length ? prices[0]! : null;
    const expectedCost = p && p.cost > 0 ? p.cost : null;
    const priceDiffPct = dollars && unitPrice !== null && expectedCost !== null ? (unitPrice - expectedCost) / expectedCost : null;
    let status: RowStatus = received === ol.quantity ? "ok" : received === 0 ? "missing" : received < ol.quantity ? "short" : "over";
    let note = "";
    if (unknownQty) {
      status = "ok";
      note = "Listed, but the quantity couldn’t be read — check it by hand.";
    } else if (status === "missing") note = `Requested ${ol.quantity}, not on the document.`;
    else if (status === "short") note = `Requested ${ol.quantity}, document shows ${received} — ${ol.quantity - received} short.`;
    else if (status === "over") note = `Requested ${ol.quantity}, document shows ${received} — ${received - ol.quantity} more than requested.`;
    if (priceDiffPct !== null && Math.abs(priceDiffPct) > PRICE_TOLERANCE)
      note += `${note ? " " : ""}Billed ${unitPrice!.toFixed(2)} per unit vs your cost ${expectedCost!.toFixed(2)} (${priceDiffPct > 0 ? "+" : ""}${(priceDiffPct * 100).toFixed(1)}%).`;
    rows.push({ key: `req-${ol.productId}`, name, productId: ol.productId, requested: ol.quantity, received, status, unitPrice, expectedCost, priceDiffPct, isNew: false, note });
  }

  lines.forEach((l, i) => {
    if (claimed.has(i)) return;
    const p = state.products.find((x) => x.id === l.productId);
    const qty = unitQty(l) ?? 0;
    rows.push({
      key: `extra-${i}`,
      name: p ? `${p.name}${p.size ? ` (${p.size})` : ""}` : l.name?.trim() || l.description,
      productId: l.productId,
      requested: 0,
      received: qty,
      status: "extra",
      unitPrice: unitCost(l),
      expectedCost: p && p.cost > 0 ? p.cost : null,
      priceDiffPct: null,
      isNew: !p,
      note: p ? "Not on your request." : "Not on your request, and not in your inventory yet.",
    });
  });

  const counts = {
    ok: rows.filter((r) => r.status === "ok").length,
    short: rows.filter((r) => r.status === "short").length,
    over: rows.filter((r) => r.status === "over").length,
    missing: rows.filter((r) => r.status === "missing").length,
    extra: rows.filter((r) => r.status === "extra").length,
    priceFlags: rows.filter((r) => r.priceDiffPct !== null && Math.abs(r.priceDiffPct) > PRICE_TOLERANCE).length,
  };
  const requestedValue = r2(order.lines.reduce((n, l) => n + l.quantity * (state.products.find((p) => p.id === l.productId)?.cost ?? 0), 0));
  const sum = doc.lines.reduce((n, l) => n + (l.amount ?? (l.quantity !== null && l.unitPrice !== null ? l.quantity * l.unitPrice : 0)), 0);
  const documentValue = doc.total ?? (doc.lines.length ? r2(sum) : null);

  const issues: string[] = [];
  if (doc.issuer && !sameParty(doc.issuer, order.supplier) && !sameParty(order.supplier, doc.issuer))
    issues.push(`The document is from “${doc.issuer}”, but request ${order.id} was sent to “${order.supplier}”.`);
  for (const r of rows) if (r.status !== "ok" || (r.priceDiffPct !== null && Math.abs(r.priceDiffPct) > PRICE_TOLERANCE)) issues.push(`${r.name}: ${r.note}`);
  if (dollars && documentValue !== null && requestedValue > 0 && Math.abs(documentValue - requestedValue) / requestedValue > 0.05)
    issues.push(`Document total ${documentValue.toFixed(2)} vs about ${requestedValue.toFixed(2)} expected from the request at your usual costs.`);

  return { order, doc, rows, counts, requestedValue, documentValue, issues, complete: counts.short + counts.missing + counts.over + counts.extra + counts.priceFlags === 0 && issues.length === 0 };
}

/** Finds a scanned or saved document by id; "latest" means the newest scan (or, failing that, saved invoice/delivery note). */
export function findCompareDoc(state: StoreState, id: string): CompareDoc | undefined {
  const key = id.trim();
  if (!key || key.toLowerCase() === "latest") {
    const s = (state.scans ?? []).find((x) => x.lines.length);
    if (s) return docFromScan(s);
    const d = (state.documents ?? []).find((x) => x.kind === "Invoice" || x.kind === "Delivery note");
    return d ? docFromStoreDocument(d, state) : undefined;
  }
  const scan = (state.scans ?? []).find((x) => x.id === key);
  if (scan) return docFromScan(scan);
  const doc = (state.documents ?? []).find((x) => x.id === key || x.reference === key || x.number === key);
  return doc ? docFromStoreDocument(doc, state) : undefined;
}

/** The request that most likely belongs to this paperwork (same supplier, most shared products, still open first). */
export function suggestOrder(state: StoreState, doc: CompareDoc): Order | undefined {
  const ids = new Set(doc.lines.map((l) => l.productId ?? matchProduct(state.products, l.description)?.id).filter(Boolean));
  let best: { o: Order; score: number } | undefined;
  for (const o of state.orders) {
    const shared = o.lines.filter((l) => ids.has(l.productId)).length;
    const supplier = doc.issuer && (sameParty(doc.issuer, o.supplier) || sameParty(o.supplier, doc.issuer)) ? 1 : 0;
    const score = shared * 10 + supplier * 5 + (o.status === "Approved" ? 2 : o.status === "Draft" ? 1 : 0);
    if (score > 0 && (!best || score > best.score)) best = { o, score };
  }
  return best?.o;
}

/** A ready-to-send note to the supplier listing what is wrong. Empty when everything matches. */
export function supplierMessage(c: Comparison, store: string): string {
  const bad = c.rows.filter((r) => r.status !== "ok" || (r.priceDiffPct !== null && Math.abs(r.priceDiffPct) > PRICE_TOLERANCE));
  if (!bad.length) return "";
  const out = [`Hello${c.order.supplier ? `, ${c.order.supplier}` : ""},`, "", `We checked ${c.doc.label} against our request ${c.order.id} and found the following:`];
  for (const r of bad) out.push(`- ${r.name}: ${r.note}`);
  out.push("", "Please confirm how you will correct this (missing delivery, credit note or revised invoice).", "", `Thank you,\n${store}`);
  return out.join("\n");
}

/* ------------------------------ built-in examples ------------------------------ */

export type ExampleDoc = { id: string; title: string; blurb: string; orderId: string; doc: CompareDoc };

/**
 * Sample paperwork generated from the requests currently in the shop, so the comparison can be tried
 * with no scanning and no internet. Nothing here is saved.
 */
export function exampleDocs(state: StoreState): ExampleDoc[] {
  const preferred = ["PO-1040", "PO-1042", "PO-1041"];
  const pool = [...state.orders.filter((o) => preferred.includes(o.id)).sort((a, b) => preferred.indexOf(a.id) - preferred.indexOf(b.id)), ...state.orders.filter((o) => !preferred.includes(o.id))].filter((o) => o.lines.length);
  const build = (o: Order, tweak: (l: ScanLine, i: number) => ScanLine | null): ScanLine[] =>
    o.lines.flatMap((ol, i) => {
      const p = state.products.find((x) => x.id === ol.productId);
      if (!p) return [];
      const base: ScanLine = { description: `${p.name}${p.size ? ` ${p.size}` : ""}`, quantity: ol.quantity, unitPrice: p.cost, amount: r2(ol.quantity * p.cost), productId: p.id };
      const t = tweak(base, i);
      return t ? [{ ...t, amount: t.quantity !== null && t.unitPrice !== null ? r2(t.quantity * t.unitPrice) : t.amount }] : [];
    });
  const wrap = (o: Order, kind: string, number: string, lines: ScanLine[]): CompareDoc => ({
    label: `${kind} ${number}`,
    kind,
    number,
    issuer: o.supplier,
    currency: "USD",
    total: r2(lines.reduce((n, l) => n + (l.amount ?? 0), 0)),
    lines,
  });
  const out: ExampleDoc[] = [];
  const [a, b, c] = pool;
  if (a) {
    const lines = build(a, (l, i) => (i === 0 ? { ...l, quantity: Math.max(1, Math.floor((l.quantity ?? 1) * 0.75)) } : i === 1 ? null : l));
    out.push({ id: "ex-short", title: "Delivery note with short and missing items", blurb: "One product arrived short and another didn’t arrive at all.", orderId: a.id, doc: wrap(a, "Delivery note", "DN-EX-001", lines) });
  }
  if (b) {
    const lines = build(b, (l, i) => (i === 0 ? { ...l, unitPrice: r2((l.unitPrice ?? 0) * 1.12) } : l));
    lines.push({ description: "New Arrival Sparkling Lemonade 500 ml", name: "New Arrival Sparkling Lemonade", size: "500 ml", category: "Beverages", quantity: 24, unitPrice: 0.95, amount: 22.8 });
    out.push({ id: "ex-price", title: "Invoice with a price rise and an item you didn’t request", blurb: "Quantities match, but one price is 12% higher and a new product was added.", orderId: b.id, doc: wrap(b, "Invoice", "INV-EX-002", lines) });
  }
  if (c) out.push({ id: "ex-ok", title: "Delivery that matches perfectly", blurb: "Every requested item, correct quantity, correct price.", orderId: c.id, doc: wrap(c, "Delivery note", "DN-EX-003", build(c, (l) => l)) });
  return out;
}
