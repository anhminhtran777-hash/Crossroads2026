/**
 * Offline pricing guidance for new products and cost changes.
 *
 * The goal is the price that earns the most without being so high that shoppers walk or so low that
 * margin is given away: anchored on what similar items in YOUR shop already sell for, nudged for
 * item size, snapped to a shop-style price ending, and always kept inside hard guard-rails so neither
 * a rule nor the AI can set a loss-making or absurd price.
 */
import type { Category, Product, StoreState } from "./model";
import { tokens } from "./scan-checks";

export const MIN_MARKUP = 1.15; // never less than 15% over cost
export const MAX_MARKUP = 2.6;
const DEFAULT_MARKUP: Record<Category, number> = {
  Beverages: 1.8,
  Snacks: 1.6,
  Dairy: 1.35,
  Bakery: 1.6,
  Produce: 1.5,
  Household: 1.55,
};

export type PriceSuggestion = {
  price: number;
  floor: number;
  ceiling: number;
  markup: number;
  marginPct: number;
  basis: string;
};

const round2 = (n: number) => Math.round(n * 100) / 100;
const median = (xs: number[]) => {
  const s = [...xs].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m]! : (s[m - 1]! + s[m]!) / 2;
};

/** Snaps to a familiar shelf price: …9 under $10, …49/…99 above (never below `floor`). */
export function charm(price: number, floor: number): number {
  const step = price < 10 ? 0.1 : 0.5;
  let p = round2(Math.round(price / step) * step - 0.01);
  let guard = 0;
  while (p < floor && guard++ < 100) p = round2(p + step);
  return p;
}

export function suggestPrice(
  state: StoreState,
  item: { name: string; category: Category; cost: number; supplier?: string | undefined },
): PriceSuggestion {
  const cost = item.cost;
  const peers = state.products.filter((p) => !p.archived && p.category === item.category && p.cost > 0 && p.price > p.cost);
  const nameTokens = tokens(item.name);
  let relative: Product | undefined;
  let best = 0.5;
  for (const p of peers) {
    const pt = new Set(tokens(p.name));
    const overlap = nameTokens.length ? nameTokens.filter((t) => pt.has(t)).length / nameTokens.length : 0;
    if (overlap >= best) {
      best = overlap;
      relative = p;
    }
  }
  // Items that already sell count double: they show what shoppers really accept.
  const markups = peers.flatMap((p) => {
    const m = p.price / p.cost;
    return p.sold.some((n) => n > 0) ? [m, m] : [m];
  });
  const parts: string[] = [];
  let markup: number;
  if (relative) {
    const rel = relative.price / relative.cost;
    markup = peers.length >= 3 ? rel * 0.6 + median(markups) * 0.4 : rel;
    parts.push(`similar item “${relative.name}” sells at ×${rel.toFixed(2)} its cost`);
    if (peers.length >= 3) parts.push(`${peers.length} ${item.category.toLowerCase()} items have a median ×${median(markups).toFixed(2)}`);
  } else if (peers.length >= 3) {
    markup = median(markups);
    parts.push(`${peers.length} ${item.category.toLowerCase()} items in your shop have a median markup of ×${markup.toFixed(2)}`);
  } else {
    markup = DEFAULT_MARKUP[item.category];
    parts.push(`typical ${item.category.toLowerCase()} markup of ×${markup.toFixed(2)} (not enough similar items to learn from yet)`);
  }
  if (cost < 0.5) {
    markup *= 1.1;
    parts.push("small-ticket item, so a little more headroom");
  } else if (cost > 8) {
    markup *= 0.92;
    parts.push("higher-ticket item, so a slightly tighter markup keeps it competitive");
  }
  const floor = round2(cost * MIN_MARKUP);
  const topPeer = peers.length >= 3 ? Math.max(...markups) * 1.1 : MAX_MARKUP;
  const ceiling = Math.max(round2(cost * Math.min(MAX_MARKUP, topPeer)), round2(floor * 1.05));
  let price = charm(cost * markup, floor);
  if (price > ceiling) price = charm(ceiling, floor) > ceiling ? ceiling : charm(ceiling - 0.1, floor);
  price = Math.min(Math.max(price, floor), ceiling);
  return { price, floor, ceiling, markup: price / cost, marginPct: Math.round(((price - cost) / price) * 100), basis: `Priced from your own data: ${parts.join("; ")}.` };
}

/** Keeps any proposed price (for example the AI's) inside the guard-rails and says if it had to move it. */
export function clampPrice(proposed: number, s: PriceSuggestion): { price: number; adjusted: boolean; note: string } {
  const p = round2(proposed);
  if (!Number.isFinite(p) || p <= 0) return { price: s.price, adjusted: true, note: "Proposed price was invalid, so the suggested price was used." };
  if (p < s.floor) return { price: charm(s.floor, s.floor), adjusted: true, note: `Raised to the minimum (15% over cost) — the proposed ${p.toFixed(2)} would barely cover the item.` };
  if (p > s.ceiling) return { price: s.ceiling, adjusted: true, note: `Lowered to ${s.ceiling.toFixed(2)} — the proposed ${p.toFixed(2)} is above what similar items sell for.` };
  return { price: p, adjusted: false, note: "" };
}

/** What to do with the selling price when the supplier's cost changes. */
export function suggestReprice(state: StoreState, p: Product, newCost: number): { price: number; changed: boolean; note: string } {
  if (!(newCost > 0)) return { price: p.price, changed: false, note: "No valid new cost." };
  if (newCost <= p.cost) {
    return { price: p.price, changed: false, note: "Cost went down or stayed the same — keeping your price so the extra margin is yours." };
  }
  const floor = round2(newCost * MIN_MARKUP);
  const currentMarkup = p.cost > 0 ? p.price / p.cost : 0;
  const base = currentMarkup >= MIN_MARKUP ? currentMarkup : suggestPrice(state, { name: p.name, category: p.category, cost: newCost }).markup;
  const price = charm(newCost * base, floor);
  return price > p.price
    ? { price, changed: true, note: `Cost rose from ${p.cost.toFixed(2)} to ${newCost.toFixed(2)}; this keeps your margin at about ${Math.round((1 - 1 / base) * 100)}%.` }
    : { price: p.price, changed: false, note: "Your current price still covers the new cost with a healthy margin." };
}
