/**
 * Authorizations: the only things in Stock Genie that wait for a person.
 *
 * The AI does the work (drafting, pricing, paperwork, checking, sales, reports) on its own. Anything that
 * spends money, accepts goods, pays money back, writes stock off, hides a product or raises the spending
 * limit is turned into an *authorization request*. The assistant can only ask for one — it is shown in the
 * chat as an Approve / Decline card, and it is the app (never the model) that carries it out, and only
 * after a manager clicks Approve.
 */
import {
  approveOrder,
  confirmSupplier,
  money,
  orderCost,
  receiveOrder,
  refundSale,
  removeStock,
  supplierDocuments,
  type RefundLine,
  type StoreState,
  refundConditions,
} from "./model";

export type AuthRequest =
  | { kind: "approve_orders"; orderIds: string[] }
  | { kind: "receive_orders"; orderIds: string[] }
  | { kind: "customer_refund"; receiptId: string; lines: RefundLine[]; reason: string; condition: (typeof refundConditions)[number]; note: string }
  | { kind: "stock_removal"; productId: string; quantity: number; mode: "remove" | "return"; reason: string }
  | { kind: "archive_product"; productId: string }
  | { kind: "set_budget"; amount: number };

export type AuthStatus = "pending" | "approved" | "declined" | "failed";
export type Authorization = {
  id: string;
  request: AuthRequest;
  title: string;
  /** Plain-language bullet lines shown on the card. */
  details: string[];
  /** Money involved, when there is any. */
  amount?: number;
  status: AuthStatus;
  /** What happened once decided. */
  result?: string;
};

export const authLabels: Record<AuthRequest["kind"], string> = {
  approve_orders: "Approve purchase",
  receive_orders: "Accept delivery",
  customer_refund: "Refund customer",
  stock_removal: "Write off stock",
  archive_product: "Archive product",
  set_budget: "Change purchase budget",
};

type Prep = { ok: true; auth: Authorization } | { ok: false; error: string };
const fail = (error: string): Prep => ({ ok: false, error });
const uniq = (xs: string[]) => [...new Set(xs.map((x) => x.trim()).filter(Boolean))];
const r2 = (n: number) => Math.round(n * 100) / 100;
let counter = 0;
const newId = () => `auth-${Date.now().toString(36)}-${(counter++).toString(36)}`;

const productLabel = (state: StoreState, id: string) => {
  const p = state.products.find((x) => x.id === id);
  return p ? `${p.name}${p.size ? ` (${p.size})` : ""}` : id;
};

/** Checks a request against the current data and, if it makes sense, turns it into a card for the person. */
export function prepareAuthorization(state: StoreState, req: AuthRequest, ctx: { budget: number; budgetLeft: number }): Prep {
  switch (req.kind) {
    case "approve_orders": {
      const ids = uniq(req.orderIds);
      if (!ids.length) return fail("No purchase request was named.");
      const orders = [];
      for (const id of ids) {
        const o = state.orders.find((x) => x.id === id);
        if (!o) return fail(`Purchase request ${id} does not exist.`);
        if (o.status !== "Draft") return fail(`${id} is already ${o.status.toLowerCase()} — nothing to approve.`);
        orders.push(o);
      }
      const total = orders.reduce((n, o) => n + orderCost(state, o), 0);
      const details = orders.map((o) => `${o.id} · ${o.supplier} · ${o.lines.length} line${o.lines.length > 1 ? "s" : ""} · ${money(orderCost(state, o))}`);
      if (total > ctx.budgetLeft) details.push(`Heads-up: this is ${money(total - Math.max(ctx.budgetLeft, 0))} more than the purchase budget has left (${money(ctx.budgetLeft)}).`);
      return {
        ok: true,
        auth: {
          id: newId(), request: { kind: "approve_orders", orderIds: ids },
          title: ids.length === 1 ? `Approve purchase ${ids[0]}` : `Approve ${ids.length} purchases`,
          details, amount: r2(total), status: "pending",
        },
      };
    }
    case "receive_orders": {
      const ids = uniq(req.orderIds);
      if (!ids.length) return fail("No purchase order was named.");
      const orders = [];
      for (const id of ids) {
        const o = state.orders.find((x) => x.id === id);
        if (!o) return fail(`Purchase order ${id} does not exist.`);
        if (o.status === "Draft") return fail(`${id} is still a draft. It has to be approved before goods can be received.`);
        if (o.status === "Received") return fail(`${id} was already received.`);
        orders.push(o);
      }
      const total = orders.reduce((n, o) => n + orderCost(state, o), 0);
      const units = orders.reduce((n, o) => n + o.lines.reduce((m, l) => m + l.quantity, 0), 0);
      const details = orders.map((o) => `${o.id} · ${o.supplier} · ${o.lines.reduce((n, l) => n + l.quantity, 0)} units · ${money(orderCost(state, o))}`);
      details.push(`Adds ${units} units to your stock.`);
      return {
        ok: true,
        auth: {
          id: newId(), request: { kind: "receive_orders", orderIds: ids },
          title: ids.length === 1 ? `Accept delivery for ${ids[0]}` : `Accept ${ids.length} deliveries`,
          details, amount: r2(total), status: "pending",
        },
      };
    }
    case "customer_refund": {
      const receipt = (state.documents ?? []).find((d) => d.id === req.receiptId && d.kind === "Receipt");
      if (!receipt) return fail(`Receipt ${req.receiptId} was not found.`);
      const cond = refundConditions.find((c) => c === req.condition) ?? "Resellable";
      const test = refundSale(state, {
        receiptId: req.receiptId, lines: req.lines, reason: req.reason, note: req.note ?? "", condition: cond,
        approvedBy: "check", actor: "check", time: new Date().toISOString(), refundNo: "RF-check",
      });
      if (test.error || !test.refund) return fail(test.error ?? "That refund is not possible.");
      return {
        ok: true,
        auth: {
          id: newId(), request: { ...req, condition: cond },
          title: `Refund ${money(test.refund.total)} on receipt ${req.receiptId}`,
          details: [
            ...test.refund.lines.map((l) => `${l.quantity} × ${l.name} · ${money(l.quantity * l.unit)}`),
            `Reason: ${req.reason}${req.note ? ` — ${req.note}` : ""}`,
            cond === "Resellable" ? "Items go back on the shelf." : "Items are written off as damaged.",
          ],
          amount: r2(test.refund.total), status: "pending",
        },
      };
    }
    case "stock_removal": {
      const p = state.products.find((x) => x.id === req.productId);
      if (!p || p.archived) return fail("That product was not found.");
      if (!Number.isInteger(req.quantity) || req.quantity <= 0 || req.quantity > p.stock) return fail(`Only ${p.stock} units of ${p.name} are in stock.`);
      if (!req.reason.trim()) return fail("A reason is required.");
      const value = req.quantity * p.cost;
      return {
        ok: true,
        auth: {
          id: newId(), request: req,
          title: `${req.mode === "return" ? "Return" : "Write off"} ${req.quantity} × ${productLabel(state, p.id)}`,
          details: [
            `Stock goes from ${p.stock} to ${p.stock - req.quantity}.`,
            `Reason: ${req.reason}`,
            req.mode === "return" ? `Counted as a supplier return worth ${money(value)} at cost.` : `A loss of ${money(value)} at cost.`,
          ],
          amount: r2(value), status: "pending",
        },
      };
    }
    case "archive_product": {
      const p = state.products.find((x) => x.id === req.productId);
      if (!p || p.archived) return fail("That product was not found or is already archived.");
      return {
        ok: true,
        auth: {
          id: newId(), request: req, title: `Archive ${productLabel(state, p.id)}`,
          details: [`It disappears from the cashier and from restocking (${p.stock} units currently in stock).`, "Its history is kept."],
          status: "pending",
        },
      };
    }
    case "set_budget": {
      if (!Number.isFinite(req.amount) || req.amount < 0 || req.amount > 1_000_000) return fail("The budget must be a sensible amount of money.");
      return {
        ok: true,
        auth: {
          id: newId(), request: { kind: "set_budget", amount: r2(req.amount) }, title: `Set purchase budget to ${money(req.amount)}`,
          details: [`Currently ${money(ctx.budget)}.`], amount: r2(req.amount), status: "pending",
        },
      };
    }
  }
}

export type ExecResult = { state: StoreState; ok: boolean; note: string; budget?: number };

/** Carries out an approved request. Re-checks everything, because the data may have changed since the card appeared. */
export function executeAuthorization(state: StoreState, req: AuthRequest, actor: string, now = new Date()): ExecResult {
  const t = (i = 0) => new Date(now.getTime() + i).toISOString();
  switch (req.kind) {
    case "approve_orders": {
      let s = state;
      const done: string[] = [];
      req.orderIds.forEach((id, i) => {
        const next = approveOrder(s, id, actor, t(i * 3));
        if (next === s) return;
        // Supplier paperwork is simulated in this build, so it arrives automatically after approval.
        s = confirmSupplier(next, id, "Both", actor, t(i * 3 + 1));
        done.push(id);
      });
      if (!done.length) return { state, ok: false, note: "Nothing was approved — those requests are no longer drafts." };
      return { state: s, ok: true, note: `Approved ${done.join(", ")}. The supplier’s invoice and delivery note were recorded; stock changes only when you accept the delivery.` };
    }
    case "receive_orders": {
      let s = state;
      const done: string[] = [];
      req.orderIds.forEach((id, i) => {
        const order = s.orders.find((o) => o.id === id);
        if (!order || order.status !== "Approved") return;
        const docs = supplierDocuments(s, id);
        const withDocs = docs.invoice && docs.delivery ? s : confirmSupplier(s, id, "Both", actor, t(i * 3));
        const next = receiveOrder(withDocs, id, actor, t(i * 3 + 2));
        if (next === withDocs) return;
        s = next;
        done.push(id);
      });
      if (!done.length) return { state, ok: false, note: "Nothing was received — those orders are not in an approved state." };
      return { state: s, ok: true, note: `Received ${done.join(", ")}. Stock has been updated.` };
    }
    case "customer_refund": {
      const n = (state.documents ?? []).filter((d) => d.kind === "Refund receipt").length;
      let no = `RF-${1000 + n + 1}`;
      while ((state.documents ?? []).some((d) => d.id === no)) no = `RF-${Number(no.slice(3)) + 1}`;
      const res = refundSale(state, {
        receiptId: req.receiptId, lines: req.lines, reason: req.reason, note: req.note ?? "", condition: req.condition,
        approvedBy: actor, actor, time: t(), refundNo: no,
      });
      if (res.error || !res.refund) return { state, ok: false, note: res.error ?? "The refund could not be completed." };
      return { state: res.state, ok: true, note: `Refund ${no} for ${money(res.refund.total)} recorded.` };
    }
    case "stock_removal": {
      const next = removeStock(state, req.productId, req.quantity, req.mode, req.reason, actor, t());
      if (next === state) return { state, ok: false, note: "The stock could not be removed — check the quantity." };
      return { state: next, ok: true, note: req.mode === "return" ? "Recorded as returned to the supplier." : "Stock written off." };
    }
    case "archive_product": {
      const p = state.products.find((x) => x.id === req.productId);
      if (!p || p.archived) return { state, ok: false, note: "That product is no longer active." };
      return {
        ok: true, note: `${p.name} archived.`,
        state: {
          ...state,
          products: state.products.map((x) => (x.id === p.id ? { ...x, archived: true } : x)),
          activities: [{ id: `${t()}-${p.id}-archive`, product: p.name, actor, action: "Product archived", time: t() }, ...state.activities],
        },
      };
    }
    case "set_budget":
      return { state, ok: true, note: `Purchase budget is now ${money(req.amount)}.`, budget: req.amount };
  }
}
