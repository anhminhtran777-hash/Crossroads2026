import { useMemo, useRef, useState } from "react";
import { ScanLine as ScanIcon, Upload, X, Check, TriangleAlert, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { MessageResponse } from "@/components/ai-elements/message";
import { Link } from "@tanstack/react-router";
import { useStockPilot } from "./store";
import { money, type StoreDocument } from "./model";
import { bridge, useAiStatus, useOnline } from "./desktop";
import { type ScanRecord } from "./scan-checks";
import { scanFiles, type Mode } from "./scan-read";
import { docFromScan } from "./compare";
import { CompareWithRequest } from "./compare-panel";

const modes: { id: Mode; label: string; hint: string }[] = [
  { id: "summarize", label: "Summarize", hint: "Who, what, how much — in a few sentences" },
  { id: "explain", label: "Explain it to me", hint: "Plain-language walkthrough and what to do next" },
  { id: "extract", label: "Extract & check", hint: "Pull out every line and compare with your records" },
];
const MAX_FILES = 8;
const MAX_PDF_BYTES = 20 * 1024 * 1024;

export function ScanDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const { state, setState, user, role } = useStockPilot();
  const online = useOnline();
  const ai = useAiStatus(open ? 1 : 0);
  const [files, setFiles] = useState<File[]>([]);
  const [mode, setMode] = useState<Mode>("summarize");
  const [question, setQuestion] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<ScanRecord | null>(null);
  const [saved, setSaved] = useState(false);
  const [added, setAdded] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const ready = !!bridge() && online && !!ai?.hasKey;
  const history = state.scans ?? [];

  const add = (list: FileList | File[]) => {
    const next = [...files];
    for (const f of Array.from(list)) {
      const okType = /^image\/(png|jpe?g|webp|gif)$/.test(f.type) || f.type === "application/pdf";
      if (!okType) setError(`“${f.name}” isn’t supported. Use a photo (JPG, PNG, WEBP) or a PDF.`);
      else if (f.type === "application/pdf" && f.size > MAX_PDF_BYTES) setError(`“${f.name}” is larger than 20 MB.`);
      else if (next.length < MAX_FILES) next.push(f);
      else setError(`You can scan up to ${MAX_FILES} files at once.`);
    }
    setFiles(next);
  };

  const run = async () => {
    setBusy(true);
    setError("");
    setResult(null);
    setSaved(false);
    setAdded(false);
    try {
      setResult(await scanFiles(files, { mode, question: question.trim(), state, user }));
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  const save = () => {
    if (!result || saved) return;
    setState((s) => ({ ...s, scans: [result, ...(s.scans ?? [])].slice(0, 200) }));
    setSaved(true);
  };
  const addAccounting = () => {
    if (!result || !result.total || !result.issuer || added) return;
    const date = result.date && Number.isFinite(Date.parse(result.date)) ? new Date(`${result.date}T12:00:00`).toISOString() : new Date().toISOString();
    const doc: StoreDocument = {
      id: `ACC-${Date.now()}`,
      kind: "Accounting invoice",
      reference: result.number ?? result.id,
      number: result.number ?? result.id,
      party: result.issuer,
      actor: user,
      time: date,
      lines: result.lines.length ? result.lines.map((l) => ({ name: l.description, quantity: l.quantity ?? 1, unit: l.unitPrice ?? l.amount ?? 0 })) : [{ name: result.summary || "Scanned invoice", quantity: 1, unit: result.total }],
      total: result.total,
      note: "Scanned",
    };
    setState((s) => ({ ...s, documents: [doc, ...(s.documents ?? [])], scans: s.scans?.some((x) => x.id === result.id) ? s.scans : [result, ...(s.scans ?? [])] }));
    setSaved(true);
    setAdded(true);
  };
  const reset = () => {
    setFiles([]);
    setResult(null);
    setError("");
    setQuestion("");
  };
  const compareDoc = useMemo(() => (result ? docFromScan(result) : null), [result]);
  const isInvoice = !!result && /invoice|credit/i.test(result.documentType);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="scan-dialog">
        <DialogHeader>
          <DialogTitle>Scan a document</DialogTitle>
          <DialogDescription>Invoices, receipts and delivery notes — photos or PDFs. Reading needs an internet connection; nothing here changes your stock.</DialogDescription>
        </DialogHeader>
        {!ready && (
          <p className="scan-notice" role="status">
            <TriangleAlert size={15} />
            {!bridge()
              ? "Document scanning is available in the Stock Genie desktop app."
              : !online
                ? "You’re offline. Scanning needs the internet — the rest of the app keeps working."
                : <>Add your API key in <Link to="/settings" search={{ tab: "profile" }} onClick={() => onOpenChange(false)} className="underline">Settings → AI &amp; data</Link> to turn scanning on.</>}
          </p>
        )}
        {!result ? (
          <div className="scan-body">
            <div
              className="scan-drop"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                add(e.dataTransfer.files);
              }}
            >
              <Upload size={22} />
              <p>Drop photos or PDFs here</p>
              <Button type="button" variant="outline" size="sm" onClick={() => input.current?.click()}>Choose files</Button>
              <input ref={input} type="file" hidden multiple accept="image/png,image/jpeg,image/webp,image/gif,application/pdf" onChange={(e) => { if (e.target.files) add(e.target.files); e.target.value = ""; }} />
            </div>
            {files.length > 0 && (
              <ul className="scan-files">
                {files.map((f, i) => (
                  <li key={`${f.name}-${i}`}>
                    <FileText size={14} />
                    <span>{f.name}</span>
                    <small>{(f.size / 1024).toFixed(0)} KB</small>
                    <button type="button" aria-label={`Remove ${f.name}`} onClick={() => setFiles(files.filter((_, j) => j !== i))}><X size={14} /></button>
                  </li>
                ))}
              </ul>
            )}
            <div className="scan-modes" role="group" aria-label="What do you need?">
              {modes.map((m) => (
                <Button key={m.id} type="button" variant="outline" aria-pressed={mode === m.id} onClick={() => setMode(m.id)}>
                  <strong>{m.label}</strong>
                  <small>{m.hint}</small>
                </Button>
              ))}
            </div>
            <div className="product-form">
              <label>
                Anything specific to find out? (optional)
                <input value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="e.g. When is payment due? Why is the total higher than the order?" />
              </label>
            </div>
            {error && <p className="negative text-sm" role="alert">{error}</p>}
            <div className="flex justify-end gap-2">
              <Button type="button" onClick={run} disabled={!ready || busy || !files.length}>
                <ScanIcon /> {busy ? "Reading…" : "Scan"}
              </Button>
            </div>
            {history.length > 0 && (
              <div className="scan-history">
                <h3>Recent scans</h3>
                <ul>
                  {history.slice(0, 5).map((h) => (
                    <li key={h.id}>
                      <button type="button" onClick={() => { setResult(h); setSaved(true); setAdded(false); }}>
                        <strong>{h.documentType} · {h.issuer ?? "Unknown issuer"}</strong>
                        <small>{h.number ?? "no number"} · {new Date(h.time).toLocaleDateString("en-GB")}{h.total !== null ? ` · ${h.total.toFixed(2)} ${h.currency ?? ""}` : ""}</small>
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ) : (
          <div className="scan-result">
            <div className="scan-chips">
              <span>{result.documentType}</span>
              {result.issuer && <span>From: {result.issuer}</span>}
              {result.number && <span>No. {result.number}</span>}
              {result.date && <span>{result.date}</span>}
              {result.dueDate && <span>Due {result.dueDate}</span>}
              {result.total !== null && <span><strong>{result.currency && result.currency !== "USD" ? `${result.total.toFixed(2)} ${result.currency}` : money(result.total)}</strong></span>}
            </div>
            {result.summary && <MessageResponse>{result.summary}</MessageResponse>}
            {result.explanation && <MessageResponse>{result.explanation}</MessageResponse>}
            {result.answer && <div className="scan-answer"><strong>Your question</strong><MessageResponse>{result.answer}</MessageResponse></div>}
            {(result.checks.length > 0 || result.warnings.length > 0) && (
              <ul className="scan-flags" aria-label="Checks">
                {[...result.checks, ...result.warnings.map((w) => `Scanner note: ${w}`)].map((c, i) => <li key={i}><TriangleAlert size={14} />{c}</li>)}
              </ul>
            )}
            {result.lines.length > 0 && (
              <div className="scan-table">
                <table>
                  <thead><tr><th>Item</th><th>Qty</th><th>Unit</th><th>Amount</th><th>In inventory</th></tr></thead>
                  <tbody>
                    {result.lines.map((l, i) => {
                      const p = state.products.find((x) => x.id === l.productId);
                      return (
                        <tr key={i}>
                          <td>{l.description}</td>
                          <td>{l.quantity ?? "—"}</td>
                          <td>{l.unitPrice !== null ? l.unitPrice.toFixed(2) : "—"}</td>
                          <td>{l.amount !== null ? l.amount.toFixed(2) : "—"}</td>
                          <td>{p ? <span className="positive">{p.name}</span> : <span className="text-muted-foreground">Not matched</span>}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            {compareDoc && result && <CompareWithRequest key={result.id} doc={compareDoc} />}
            <div className="flex flex-wrap justify-end gap-2">
              <Button variant="outline" onClick={reset}>Scan another</Button>
              <Button variant="outline" onClick={save} disabled={saved}>{saved ? <><Check /> Saved</> : "Save this scan"}</Button>
              {role === "Manager" && isInvoice && !!result.total && !!result.issuer && (
                <Button onClick={addAccounting} disabled={added}>{added ? <><Check /> Added to Documents</> : "Add as accounting invoice"}</Button>
              )}
            </div>
            <p className="text-xs text-muted-foreground">AI can misread blurry pages — check important figures against the paper original. Scans never change stock or orders.</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

/** Button + dialog pair for the Documents page header. */
export function ScanButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button size="sm" variant="outline" onClick={() => setOpen(true)}><ScanIcon /> Scan document</Button>
      <ScanDialog open={open} onOpenChange={setOpen} />
    </>
  );
}
