/**
 * What the AI assistant is allowed to DO, and the guard-rails around it.
 *
 * Every tool works on the same functions the app's own screens use. The assistant runs the whole shop on
 * its own: drafts, products, prices (managers only, inside hard limits), sales, supplier paperwork, issue
 * reports, document checks. The few things that spend or lose money — approving a purchase, accepting a
 * delivery, refunding a customer, writing stock off, archiving a product, raising the budget — can only be
 * REQUESTED: the request becomes an Approve / Decline card in the chat and the app carries it out after a
 * manager clicks Approve (see authorizations.ts). Every change is written to the activity log.
 */
import {
  checkout,
  createPurchaseRequest,
  orderCost,
  reportDocumentIssue,
  reportIssues,
  refundConditions,
  supplierDocuments,
  type Product,
  type Role,
  type StoreState,
} from "./model";
import { applyRestockPlan, buildSnapshot, budgetLeft, dailyVelocity, restockPlan } from "./insights";
import type { AuthRequest } from "./authorizations";
import { addProduct, asCategory, canonicalSupplier, guessCategory, setPrice } from "./catalog";
import { clampPrice, suggestPrice } from "./pricing";
import { compareRequest, findCompareDoc, suggestOrder, supplierMessage } from "./compare";
import { proposeCostChanges, proposeProducts } from "./proposals";
import type { AiTool } from "./ai-client";

export const assistantTools: AiTool[] = [
  {
    name: "create_restock_drafts",
    description:
      "Create DRAFT purchase requests (one per supplier) from the smart restock plan. Drafts still need a person's approval; nothing is ordered or paid. Omit product_ids to draft the whole plan.",
    input_schema: { type: "object", properties: { product_ids: { type: "array", items: { type: "string" } } } },
  },
  {
    name: "create_purchase_draft",
    description:
      "Create ONE draft purchase request for a specific supplier with exactly the products and unit quantities the user asked for. All products must belong to that supplier. Quantities are in single units (a wholesale stack is caseSize units). The draft still needs a person's approval.",
    input_schema: {
      type: "object",
      properties: {
        supplier: { type: "string" },
        lines: { type: "array", items: { type: "object", properties: { product_id: { type: "string" }, quantity: { type: "integer" } }, required: ["product_id", "quantity"] } },
      },
      required: ["supplier", "lines"],
    },
  },
  {
    name: "find_product",
    description: "Look up products by name, SKU or barcode: stock, price, cost, margin, sales pace and supplier.",
    input_schema: { type: "object", properties: { query: { type: "string" } }, required: ["query"] },
  },
  {
    name: "suggest_price",
    description: "Get the price guidance for a product that does not exist yet (or a what-if): suggested price, the safe minimum and maximum, and why. Based on similar items in this shop.",
    input_schema: {
      type: "object",
      properties: { name: { type: "string" }, category: { type: "string", enum: ["Beverages", "Snacks", "Dairy", "Bakery", "Produce", "Household"] }, cost: { type: "number" } },
      required: ["name", "category", "cost"],
    },
  },
  {
    name: "create_product",
    description:
      "Add a new product to the inventory (managers only). Needs name, category, cost per single unit and supplier — ask the user if any is missing; never guess a cost or supplier. Omit price to use the suggested price, or pass your own price if you can justify a better one; it is kept inside safe limits. New products start with 0 stock unless initial_stock is given.",
    input_schema: {
      type: "object",
      properties: {
        name: { type: "string" },
        size: { type: "string", description: "Pack size, e.g. '500 ml'. Empty if none." },
        category: { type: "string", enum: ["Beverages", "Snacks", "Dairy", "Bakery", "Produce", "Household"] },
        cost: { type: "number", description: "Cost per single unit in US dollars." },
        supplier: { type: "string" },
        price: { type: "number" },
        initial_stock: { type: "integer" },
        reorder_point: { type: "integer" },
        case_size: { type: "integer", description: "Units per wholesale stack." },
        barcode: { type: "string" },
      },
      required: ["name", "category", "cost", "supplier"],
    },
  },
  {
    name: "update_price",
    description: "Change the selling price of an existing product (managers only), only when the user asks to change or optimise a price. Limited to ±30% per change and never below a safe margin over cost.",
    input_schema: { type: "object", properties: { product_id: { type: "string" }, new_price: { type: "number" }, reason: { type: "string" } }, required: ["product_id", "new_price"] },
  },
  {
    name: "list_documents",
    description: "List the newest scanned documents and saved invoices / delivery notes (id, type, number, issuer, currency, line count). Use it to find the id of the paperwork the user means.",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "compare_with_request",
    description:
      "Compare a purchase request with a delivery note or invoice and report what is missing, short, extra, over-delivered or re-priced, plus a ready-to-send message for the supplier. Read-only. document_id is an id from list_documents, or 'latest'. Omit order_id to pick the most likely request automatically.",
    input_schema: { type: "object", properties: { document_id: { type: "string" }, order_id: { type: "string" } }, required: ["document_id"] },
  },
  {
    name: "apply_document_updates",
    description:
      "Managers only. From a scanned/saved invoice or delivery note: add the products the shop does not stock yet (prices are chosen automatically from similar items, inside safe limits) and/or update changed supplier costs with a margin-keeping repricing. Call compare_with_request first so you can tell the user what will change. For a document not in US dollars, exchange_rate (USD per 1 unit of the document currency) is required — ask the user, never guess. Does not touch stock.",
    input_schema: {
      type: "object",
      properties: {
        document_id: { type: "string" },
        add_new_products: { type: "boolean" },
        update_costs: { type: "boolean" },
        exchange_rate: { type: "number" },
      },
      required: ["document_id"],
    },
  },
  {
    name: "get_overview",
    description: "Fresh snapshot of the whole store: totals, restock plan, low stock, open orders, paperwork, refunds, supplier issues and business findings. Call it when you need current numbers after changes were made.",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "list_orders",
    description: "List purchase requests / orders (id, supplier, status Draft|Approved|Received, value, whether the supplier's invoice and delivery note are recorded). Optionally filter by status.",
    input_schema: { type: "object", properties: { status: { type: "string", enum: ["Draft", "Approved", "Received"] } } },
  },
  {
    name: "record_sale",
    description: "Ring up a customer sale at the till: lowers stock, logs it and issues a receipt. Quantities are single units. For Cash, 'paid' (amount handed over) is required and must cover the total.",
    input_schema: {
      type: "object",
      properties: {
        lines: { type: "array", items: { type: "object", properties: { product_id: { type: "string" }, quantity: { type: "integer" } }, required: ["product_id", "quantity"] } },
        method: { type: "string", enum: ["Cash", "Card"] },
        paid: { type: "number" },
      },
      required: ["lines", "method"],
    },
  },
  {
    name: "list_receipts",
    description: "Recent customer sales receipts with their lines (needed to find a receipt id before a refund). Optionally filter by product name.",
    input_schema: { type: "object", properties: { product: { type: "string" }, limit: { type: "integer" } } },
  },
  {
    name: "report_document_issue",
    description: "File a supplier-issue report (missing or damaged items, wrong item, price mismatch) against a saved invoice, delivery note, goods receipt or purchase order. document_id comes from list_documents (source 'saved'). Lines are product names exactly as on the document with the affected quantity.",
    input_schema: {
      type: "object",
      properties: {
        document_id: { type: "string" },
        issue: { type: "string", enum: [...reportIssues] },
        lines: { type: "array", items: { type: "object", properties: { name: { type: "string" }, quantity: { type: "integer" } }, required: ["name", "quantity"] } },
        note: { type: "string" },
      },
      required: ["document_id", "issue"],
    },
  },
  {
    name: "open_screen",
    description: "Open one of the app's manual screens for the user, only when they ask to see it or a visual is clearly better than chat.",
    input_schema: { type: "object", properties: { screen: { type: "string", enum: ["inventory", "dashboard", "cashier", "orders", "documents", "reports", "activity", "settings"] } }, required: ["screen"] },
  },
  {
    name: "request_order_approval",
    description: "AUTHORIZATION: ask the manager to approve one or more DRAFT purchase requests (this commits money). Shows an Approve/Decline card in the chat; nothing is approved until the manager clicks Approve. Group all drafts you want approved into ONE call. After approval the supplier's invoice and delivery note are recorded automatically.",
    input_schema: { type: "object", properties: { order_ids: { type: "array", items: { type: "string" } } }, required: ["order_ids"] },
  },
  {
    name: "request_delivery_acceptance",
    description: "AUTHORIZATION: ask the manager to accept the delivery of one or more APPROVED purchase orders (adds the goods to stock and closes the order). Shows an Approve/Decline card; nothing changes until the manager clicks Approve. Group them in ONE call.",
    input_schema: { type: "object", properties: { order_ids: { type: "array", items: { type: "string" } } }, required: ["order_ids"] },
  },
  {
    name: "request_customer_refund",
    description: "AUTHORIZATION: ask the manager to refund items from a sales receipt (find the receipt with list_receipts). Shows an Approve/Decline card; the refund is only made after Approve.",
    input_schema: {
      type: "object",
      properties: {
        receipt_id: { type: "string" },
        lines: { type: "array", items: { type: "object", properties: { product_id: { type: "string" }, quantity: { type: "integer" } }, required: ["product_id", "quantity"] } },
        reason: { type: "string", enum: ["Defective item", "Changed mind", "Wrong item sold", "Expired product", "Overcharged", "Damaged packaging"] },
        condition: { type: "string", enum: [...refundConditions], description: "Resellable goes back on the shelf; Damaged is written off." },
        note: { type: "string" },
      },
      required: ["receipt_id", "lines", "reason", "condition"],
    },
  },
  {
    name: "request_stock_removal",
    description: "AUTHORIZATION: ask the manager to take units out of stock — a write-off (damaged, expired, lost…) or a return to the supplier. Shows an Approve/Decline card.",
    input_schema: {
      type: "object",
      properties: {
        product_id: { type: "string" },
        quantity: { type: "integer" },
        mode: { type: "string", enum: ["remove", "return"] },
        reason: { type: "string", description: "e.g. Damaged, Expired, Theft or loss, Count correction, Own use, Defective, Recalled" },
      },
      required: ["product_id", "quantity", "mode", "reason"],
    },
  },
  {
    name: "request_product_archive",
    description: "AUTHORIZATION: ask the manager to archive (retire) a product. Shows an Approve/Decline card.",
    input_schema: { type: "object", properties: { product_id: { type: "string" } }, required: ["product_id"] },
  },
  {
    name: "request_budget_change",
    description: "AUTHORIZATION: ask the manager to change the monthly purchase budget (the spending limit). Shows an Approve/Decline card.",
    input_schema: { type: "object", properties: { amount: { type: "number" } }, required: ["amount"] },
  },
];

export type ToolContext = {
  get: () => StoreState;
  set: (s: StoreState) => void;
  user: string;
  role: Role;
  budget: number;
  storeName?: string;
  /** Turns an authorization request into a card for the manager. Returns an error text when the request makes no sense. */
  authorize?: (req: AuthRequest) => { ok: true; title: string } | { ok: false; error: string };
  /** Opens one of the manual screens. */
  navigate?: (screen: string) => void;
};

const j = (x: unknown) => JSON.stringify(x);
const r2 = (n: number) => Math.round(n * 100) / 100;
const num = (v: unknown) => (typeof v === "number" ? v : Number(v));
const VIA = "AI assistant";

const brief = (p: Product) => ({
  id: p.id,
  name: `${p.name}${p.size ? ` (${p.size})` : ""}`,
  category: p.category,
  stock: p.stock,
  reorderPoint: p.threshold,
  price: p.price,
  cost: p.cost,
  marginPct: p.price > 0 ? Math.round(((p.price - p.cost) / p.price) * 100) : 0,
  perDay: r2(dailyVelocity(p)),
  supplier: p.supplier,
  caseSize: p.caseSize ?? 1,
  archived: !!p.archived,
});

export function createToolRunner(ctx: ToolContext) {
  const managerOnly = () => (ctx.role === "Manager" ? null : j({ error: "Only a manager can add products or change prices. Tell the user to ask a manager." }));
  return (name: string, input: Record<string, unknown>): string => {
    const cur = ctx.get();
    const now = new Date().toISOString();

    if (name === "find_product") {
      const q = String(input["query"] ?? "").trim().toLowerCase();
      if (!q) return j({ error: "Empty query." });
      const hits = cur.products.filter((p) => p.name.toLowerCase().includes(q) || `${p.name} ${p.size}`.toLowerCase().includes(q) || p.sku.toLowerCase() === q || p.barcode.includes(q)).slice(0, 6).map(brief);
      return j(hits.length ? hits : { error: "No matching product." });
    }

    if (name === "create_restock_drafts") {
      const ids = Array.isArray(input["product_ids"]) ? new Set((input["product_ids"] as unknown[]).map(String)) : null;
      const wanted = restockPlan(cur, { budgetLeft: budgetLeft(cur, ctx.budget) }).filter((s) => !ids || ids.has(s.product.id));
      const res = applyRestockPlan(cur, wanted, ctx.user, now);
      if (!res.created.length) return j({ created: [], note: "Nothing to draft: items are covered by open orders, over budget, or not in the plan." });
      ctx.set(res.state);
      return j({ created: res.created, note: "Drafts created. A person must approve them in Purchase Orders." });
    }

    if (name === "create_purchase_draft") {
      const supplier = canonicalSupplier(cur, String(input["supplier"] ?? ""));
      const raw = Array.isArray(input["lines"]) ? (input["lines"] as Record<string, unknown>[]) : [];
      if (!supplier || !raw.length) return j({ error: "A supplier and at least one line are required." });
      const merged = new Map<string, number>();
      const problems: string[] = [];
      for (const l of raw) {
        const id = String(l["product_id"] ?? "");
        const qty = num(l["quantity"]);
        const p = cur.products.find((x) => x.id === id);
        if (!p) problems.push(`Unknown product id “${id}” — use find_product to get ids.`);
        else if (p.archived) problems.push(`${p.name} is archived.`);
        else if (p.supplier !== supplier) problems.push(`${p.name} belongs to ${p.supplier || "no supplier"}, not ${supplier}.`);
        else if (!Number.isSafeInteger(qty) || qty <= 0) problems.push(`${p.name}: quantity must be a whole number above zero.`);
        else merged.set(id, (merged.get(id) ?? 0) + qty);
      }
      if (problems.length) return j({ error: "Draft not created.", problems });
      const before = cur.orders.length;
      const next = createPurchaseRequest(cur, supplier, [...merged].map(([productId, quantity]) => ({ productId, quantity })), ctx.user, now);
      if (next.orders.length === before) return j({ error: "The request could not be created." });
      ctx.set(next);
      const order = next.orders[0]!;
      return j({
        created: order.id,
        supplier,
        estimatedCost: r2(orderCost(next, order)),
        lines: order.lines.map((l) => {
          const p = next.products.find((x) => x.id === l.productId)!;
          const cs = p.caseSize ?? 1;
          return { name: p.name, units: l.quantity, wholeStacks: l.quantity % cs === 0 ? l.quantity / cs : null };
        }),
        note: "Draft created. A person must approve it in Purchase Orders.",
      });
    }

    if (name === "suggest_price") {
      const category = asCategory(input["category"]) ?? guessCategory(String(input["name"] ?? ""));
      const cost = num(input["cost"]);
      if (!(cost > 0)) return j({ error: "Cost must be above zero." });
      const s = suggestPrice(cur, { name: String(input["name"] ?? ""), category, cost });
      return j({ category, suggestedPrice: s.price, safeMinimum: s.floor, safeMaximum: s.ceiling, marginPct: s.marginPct, basis: s.basis });
    }

    if (name === "create_product") {
      const denied = managerOnly();
      if (denied) return denied;
      const pname = String(input["name"] ?? "").trim();
      const supplier = canonicalSupplier(cur, String(input["supplier"] ?? ""));
      const cost = num(input["cost"]);
      const category = asCategory(input["category"]) ?? guessCategory(pname);
      if (!pname || !supplier || !(cost > 0)) return j({ error: "Name, supplier and a cost above zero are required. Ask the user for what is missing." });
      const s = suggestPrice(cur, { name: pname, category, cost, supplier });
      let price = s.price;
      let note = s.basis;
      if (input["price"] !== undefined && Number.isFinite(num(input["price"]))) {
        const c = clampPrice(num(input["price"]), s);
        price = c.price;
        note = c.adjusted ? c.note : `Your proposed price is inside the safe range ${s.floor.toFixed(2)}–${s.ceiling.toFixed(2)}. ${s.basis}`;
      }
      const res = addProduct(
        cur,
        {
          name: pname,
          size: String(input["size"] ?? ""),
          category,
          cost,
          price,
          supplier,
          stock: input["initial_stock"] === undefined ? undefined : num(input["initial_stock"]),
          threshold: input["reorder_point"] === undefined ? undefined : num(input["reorder_point"]),
          caseSize: input["case_size"] === undefined ? undefined : num(input["case_size"]),
          barcode: typeof input["barcode"] === "string" ? input["barcode"] : undefined,
        },
        ctx.user,
        now,
        VIA,
      );
      if (!res.product) return j({ error: res.error });
      ctx.set(res.state);
      return j({
        created: brief(res.product),
        pricingNote: note,
        reminder: res.product.stock > 0 ? undefined : "Stock is 0 until a delivery is received. Offer to draft a purchase request for it.",
      });
    }

    if (name === "update_price") {
      const denied = managerOnly();
      if (denied) return denied;
      const p = cur.products.find((x) => x.id === String(input["product_id"] ?? ""));
      const price = num(input["new_price"]);
      if (!p) return j({ error: "Product not found — use find_product to get its id." });
      if (!(price > 0)) return j({ error: "The new price must be above zero." });
      if (Math.abs(price - p.price) / p.price > 0.3) return j({ error: `That is more than a 30% change from ${p.price.toFixed(2)}. Make a smaller change, or ask the user to edit it in Inventory.` });
      const res = setPrice(cur, p.id, price, ctx.user, now, { via: VIA });
      if (!res.product) return j({ error: res.error });
      ctx.set(res.state);
      return j({ updated: brief(res.product), previousPrice: p.price });
    }

    if (name === "list_documents") {
      const scans = (cur.scans ?? []).slice(0, 8).map((x) => ({ id: x.id, source: "scan", type: x.documentType, number: x.number, issuer: x.issuer, currency: x.currency, lines: x.lines.length, total: x.total }));
      const docs = (cur.documents ?? [])
        .filter((d) => d.kind === "Invoice" || d.kind === "Delivery note" || d.kind === "Goods receipt")
        .slice(0, 8)
        .map((d) => ({ id: d.id, source: "saved", type: d.kind, number: d.number ?? d.reference, issuer: d.party, currency: "USD", lines: d.lines.length, total: d.total }));
      return j(scans.length || docs.length ? { documents: [...scans, ...docs] } : { error: "No scanned or saved paperwork yet. Ask the user to scan a delivery note or invoice in Documents." });
    }

    if (name === "compare_with_request") {
      const doc = findCompareDoc(cur, String(input["document_id"] ?? "latest"));
      if (!doc) return j({ error: "Document not found — use list_documents to get an id." });
      const orderId = String(input["order_id"] ?? "");
      const order = orderId ? cur.orders.find((o) => o.id === orderId) : suggestOrder(cur, doc);
      if (!order) return j({ error: orderId ? `Request ${orderId} not found.` : "No purchase request matches this document. Ask the user which request it belongs to." });
      const c = compareRequest(cur, order, doc);
      return j({
        request: order.id,
        supplier: order.supplier,
        document: doc.label,
        allGood: c.complete,
        counts: c.counts,
        requestedValueUsd: c.requestedValue,
        documentTotal: c.documentValue,
        currency: doc.currency ?? "USD",
        rows: c.rows.map((r) => ({ product: r.name, requested: r.requested, onDocument: r.received, status: r.status, priceDiffPct: r.priceDiffPct === null ? null : Math.round(r.priceDiffPct * 1000) / 10, newProduct: r.isNew, note: r.note })),
        issues: c.issues,
        supplierMessage: supplierMessage(c, "the store"),
      });
    }

    if (name === "apply_document_updates") {
      const denied = managerOnly();
      if (denied) return denied;
      const doc = findCompareDoc(cur, String(input["document_id"] ?? "latest"));
      if (!doc) return j({ error: "Document not found — use list_documents to get an id." });
      const nonUsd = !!doc.currency && doc.currency !== "USD";
      const rate = nonUsd ? num(input["exchange_rate"]) : 1;
      if (!(rate > 0)) return j({ error: `This document is in ${doc.currency}. Ask the user for the exchange rate (USD per 1 ${doc.currency}) before changing anything.` });
      const addNew = input["add_new_products"] !== false;
      const costs = input["update_costs"] !== false;
      let next = cur;
      const added: { name: string; price: number; cost: number; marginPct: number; basis: string }[] = [];
      const repriced: { name: string; cost: string; price: string; why: string }[] = [];
      const errors: string[] = [];
      const via = `${VIA}, from scanned document`;
      if (addNew)
        for (const p of proposeProducts(next, doc, rate)) {
          const res = addProduct(next, p.draft, ctx.user, now, via);
          if (res.product) {
            next = res.state;
            added.push({ name: res.product.name, price: res.product.price, cost: res.product.cost, marginPct: Math.round(((res.product.price - res.product.cost) / res.product.price) * 100), basis: p.suggestion.basis });
          } else errors.push(`${p.draft.name}: ${res.error}`);
        }
      if (costs)
        for (const c of proposeCostChanges(next, doc, rate)) {
          const res = setPrice(next, c.product.id, c.newPrice, ctx.user, now, { cost: c.newCost, via });
          if (res.product) {
            next = res.state;
            repriced.push({ name: c.product.name, cost: `${c.oldCost.toFixed(2)} → ${c.newCost.toFixed(2)}`, price: `${c.oldPrice.toFixed(2)} → ${c.newPrice.toFixed(2)}`, why: c.note });
          } else errors.push(`${c.product.name}: ${res.error}`);
        }
      if (next !== cur) ctx.set(next);
      return j({ added, repriced, errors, note: added.length || repriced.length ? "Done. New products start with 0 stock until the delivery is received." : "Nothing to add or update on this document." });
    }

    if (name === "get_overview") {
      return j(buildSnapshot(cur, { storeName: ctx.storeName ?? "Store", budgetLeft: budgetLeft(cur, ctx.budget) }));
    }

    if (name === "list_orders") {
      const want = typeof input["status"] === "string" ? input["status"] : "";
      const rows = cur.orders
        .filter((o) => !want || o.status === want)
        .slice(0, 25)
        .map((o) => {
          const docs = supplierDocuments(cur, o.id);
          return { id: o.id, supplier: o.supplier, status: o.status, date: o.date, lines: o.lines.length, units: o.lines.reduce((n, l) => n + l.quantity, 0), value: r2(orderCost(cur, o)), invoiceRecorded: !!docs.invoice, deliveryNoteRecorded: !!docs.delivery };
        });
      return j(rows.length ? { orders: rows } : { orders: [], note: "No matching orders." });
    }

    if (name === "record_sale") {
      const raw = Array.isArray(input["lines"]) ? (input["lines"] as Record<string, unknown>[]) : [];
      const method = input["method"] === "Cash" ? "Cash" : "Card";
      const merged = new Map<string, number>();
      for (const l of raw) merged.set(String(l["product_id"] ?? ""), (merged.get(String(l["product_id"] ?? "")) ?? 0) + num(l["quantity"]));
      if (!merged.size) return j({ error: "The sale has no items." });
      for (const [id, q] of merged) {
        const p = cur.products.find((x) => x.id === id);
        if (!p || p.archived) return j({ error: `Unknown or archived product id “${id}” — use find_product.` });
        if (!Number.isInteger(q) || q <= 0) return j({ error: `${p.name}: quantity must be a whole number above zero.` });
        if (q > p.stock) return j({ error: `Only ${p.stock} × ${p.name} in stock.` });
      }
      const receipts = (cur.documents ?? []).filter((d) => d.kind === "Receipt");
      let no = `R-${1000 + receipts.length + 1}`;
      while ((cur.documents ?? []).some((d) => d.id === no)) no = `R-${Number(no.slice(2)) + 1}`;
      const paid = input["paid"] === undefined ? undefined : num(input["paid"]);
      const res = checkout(cur, [...merged].map(([productId, quantity]) => ({ productId, quantity })), method, paid, ctx.user, now, no);
      if (!res.receipt) return j({ error: method === "Cash" ? "The sale was not recorded — the cash handed over must cover the total." : "The sale was not recorded." });
      ctx.set(res.state);
      const change = method === "Cash" && paid !== undefined ? r2(paid - res.receipt.total) : 0;
      return j({ receipt: no, total: r2(res.receipt.total), method, change, lines: res.receipt.lines.map((l) => ({ name: l.name, quantity: l.quantity, unit: l.unit })) });
    }

    if (name === "list_receipts") {
      const q = String(input["product"] ?? "").trim().toLowerCase();
      const limit = Math.min(Math.max(Number.isFinite(num(input["limit"])) ? num(input["limit"]) : 8, 1), 20);
      const rows = (cur.documents ?? [])
        .filter((d) => d.kind === "Receipt" && (!q || d.lines.some((l) => l.name.toLowerCase().includes(q))))
        .slice(0, limit)
        .map((d) => ({ id: d.id, time: d.time, total: r2(d.total), method: d.method, lines: d.lines.map((l) => ({ productId: l.productId, name: l.name, quantity: l.quantity, unit: l.unit })) }));
      return j(rows.length ? { receipts: rows } : { error: "No matching sales receipts." });
    }

    if (name === "report_document_issue") {
      const doc = (cur.documents ?? []).find((d) => d.id === String(input["document_id"] ?? ""));
      if (!doc) return j({ error: "Document not found — use list_documents and pick a saved document id." });
      const issue = reportIssues.find((x) => x === input["issue"]);
      if (!issue) return j({ error: `Issue must be one of: ${reportIssues.join(", ")}.` });
      const lines = (Array.isArray(input["lines"]) ? (input["lines"] as Record<string, unknown>[]) : []).map((l) => ({ name: String(l["name"] ?? ""), quantity: num(l["quantity"]), unit: doc.lines.find((x) => x.name === String(l["name"] ?? ""))?.unit ?? 0 }));
      const next = reportDocumentIssue(cur, doc, issue, lines, String(input["note"] ?? ""), ctx.user, now);
      if (next === cur) return j({ error: "The report was not filed: use product names exactly as printed on the document, quantities no larger than the document, or add a note." });
      ctx.set(next);
      return j({ filed: next.reports?.[0]?.id, issue, document: doc.number ?? doc.reference, note: "Filed. A manager can resolve it in Reports." });
    }

    if (name === "open_screen") {
      if (!ctx.navigate) return j({ error: "Screens cannot be opened from here." });
      ctx.navigate(String(input["screen"] ?? ""));
      return j({ opened: input["screen"] });
    }

    const authTools: Record<string, (i: Record<string, unknown>) => AuthRequest | string> = {
      request_order_approval: (i) => ({ kind: "approve_orders", orderIds: ((i["order_ids"] as unknown[]) ?? []).map(String) }),
      request_delivery_acceptance: (i) => ({ kind: "receive_orders", orderIds: ((i["order_ids"] as unknown[]) ?? []).map(String) }),
      request_customer_refund: (i) => ({
        kind: "customer_refund",
        receiptId: String(i["receipt_id"] ?? ""),
        lines: (Array.isArray(i["lines"]) ? (i["lines"] as Record<string, unknown>[]) : []).map((l) => ({ productId: String(l["product_id"] ?? ""), quantity: num(l["quantity"]) })),
        reason: String(i["reason"] ?? ""),
        condition: refundConditions.find((c) => c === i["condition"]) ?? "Resellable",
        note: String(i["note"] ?? ""),
      }),
      request_stock_removal: (i) => ({ kind: "stock_removal", productId: String(i["product_id"] ?? ""), quantity: num(i["quantity"]), mode: i["mode"] === "return" ? "return" : "remove", reason: String(i["reason"] ?? "") }),
      request_product_archive: (i) => ({ kind: "archive_product", productId: String(i["product_id"] ?? "") }),
      request_budget_change: (i) => ({ kind: "set_budget", amount: num(i["amount"]) }),
    };
    const makeAuth = authTools[name];
    if (makeAuth) {
      if (ctx.role !== "Manager") return j({ error: "Only a manager can authorize this. Tell the user to ask a manager to sign in and ask again." });
      if (!ctx.authorize) return j({ error: "Authorizations are not available here." });
      const req = makeAuth(input);
      if (typeof req === "string") return j({ error: req });
      const r = ctx.authorize(req);
      return j(r.ok ? { status: "awaiting_authorization", card: r.title, note: "An Approve / Decline card is now shown in the chat. NOTHING has happened yet. Do not say it was done; tell the user briefly what they are being asked to authorize." } : { error: r.error });
    }

    throw new Error(`Unknown tool ${name}`);
  };
}
