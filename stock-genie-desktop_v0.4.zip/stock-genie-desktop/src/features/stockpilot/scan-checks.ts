/** Reading and cross-checking scanned paperwork. Pure functions: the checks run offline against your own data. */
import type { Product, StoreState } from "./model";

export type ScanLine = {
  description: string;
  quantity: number | null;
  unitPrice: number | null;
  amount: number | null;
  productId?: string | undefined;
  /** Clean product name, pack size and category as the scanner understood them (used to add new products). */
  name?: string | null | undefined;
  size?: string | null | undefined;
  category?: string | null | undefined;
  /** Units inside each billed pack/case (e.g. 24 for "x24"), when printed. */
  unitsPerPack?: number | null | undefined;
  barcode?: string | null | undefined;
};
export type ScanData = {
  documentType: string;
  issuer: string | null;
  recipient: string | null;
  number: string | null;
  date: string | null;
  dueDate: string | null;
  currency: string | null;
  lines: ScanLine[];
  subtotal: number | null;
  tax: number | null;
  total: number | null;
  summary: string;
  explanation: string | null;
  answer: string | null;
  warnings: string[];
};
export type ScanRecord = ScanData & {
  id: string;
  time: string;
  actor: string;
  files: string[];
  checks: string[];
};

const num = (v: unknown): number | null => {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string") {
    const n = Number(v.replace(/[^0-9.\-]/g, ""));
    return v.trim() && Number.isFinite(n) ? n : null;
  }
  return null;
};
const str = (v: unknown): string | null => (typeof v === "string" && v.trim() ? v.trim() : null);

/** Parses the model's JSON answer defensively (it may arrive wrapped in text or code fences). */
export function parseScanJson(text: string): ScanData | null {
  const a = text.indexOf("{");
  const b = text.lastIndexOf("}");
  if (a < 0 || b <= a) return null;
  let raw: Record<string, unknown>;
  try {
    raw = JSON.parse(text.slice(a, b + 1)) as Record<string, unknown>;
  } catch {
    return null;
  }
  const lines = (Array.isArray(raw["lines"]) ? raw["lines"] : []).flatMap((l): ScanLine[] => {
    if (!l || typeof l !== "object") return [];
    const o = l as Record<string, unknown>;
    const description = str(o["description"]);
    return description
      ? [{
          description,
          quantity: num(o["quantity"]),
          unitPrice: num(o["unitPrice"]),
          amount: num(o["amount"]),
          name: str(o["name"]),
          size: str(o["size"]),
          category: str(o["category"]),
          unitsPerPack: num(o["unitsPerPack"]),
          barcode: str(o["barcode"]),
        }]
      : [];
  });
  return {
    documentType: str(raw["documentType"]) ?? "Other",
    issuer: str(raw["issuer"]),
    recipient: str(raw["recipient"]),
    number: str(raw["number"]),
    date: str(raw["date"]),
    dueDate: str(raw["dueDate"]),
    currency: str(raw["currency"])?.toUpperCase() ?? null,
    lines,
    subtotal: num(raw["subtotal"]),
    tax: num(raw["tax"]),
    total: num(raw["total"]),
    summary: str(raw["summary"]) ?? "",
    explanation: str(raw["explanation"]),
    answer: str(raw["answer"]),
    warnings: (Array.isArray(raw["warnings"]) ? raw["warnings"] : []).filter((w): w is string => typeof w === "string" && !!w.trim()),
  };
}

export const tokens = (s: string) =>
  (s.toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? []).filter((t) => t.length >= 3 || /^\d+$/.test(t));

/** Best inventory match for a printed line description, or undefined when unsure. */
export function matchProduct(products: Product[], description: string): Product | undefined {
  const lt = new Set(tokens(description));
  if (!lt.size) return undefined;
  let best: { p: Product; score: number } | undefined;
  let tie = false;
  for (const p of products) {
    if (p.archived) continue;
    const pt = tokens(p.name);
    if (!pt.length) continue;
    const hit = pt.filter((t) => lt.has(t)).length / pt.length;
    const st = tokens(p.size);
    const sizeHit = st.length ? st.filter((t) => lt.has(t)).length / st.length : 0;
    const score = hit + sizeHit * 0.25;
    if (hit < 0.99) continue; // every word of the product name must appear
    if (!best || score > best.score) {
      best = { p, score };
      tie = false;
    } else if (score === best.score) tie = true;
  }
  return best && !tie ? best.p : undefined;
}

/** Units inside one billed pack (1 when the line is already per unit). */
export const packs = (l: Pick<ScanLine, "unitsPerPack">) => (l.unitsPerPack && l.unitsPerPack > 1 ? l.unitsPerPack : 1);
/** Quantity in single units, whatever pack the document bills in. */
export const unitQty = (l: ScanLine): number | null => (l.quantity === null ? null : l.quantity * packs(l));
/** Price of a single unit, whatever pack the document bills in. */
export const unitCost = (l: ScanLine): number | null => (l.unitPrice === null ? null : l.unitPrice / packs(l));

export const sameParty = (a: string, b: string) => {
  const ta = new Set(tokens(a));
  const tb = tokens(b);
  return tb.length > 0 && tb.filter((t) => ta.has(t)).length / tb.length >= 0.5;
};
const pct = (n: number) => `${n > 0 ? "+" : ""}${(n * 100).toFixed(1)}%`;
const fmt = (n: number, cur: string | null) => `${n.toFixed(2)}${cur ? ` ${cur}` : ""}`;

/** Links lines to products and compares the document with your records. Returns the lines plus plain-language flags. */
export function checkScan(data: ScanData, state: StoreState): { lines: ScanLine[]; checks: string[] } {
  const checks: string[] = [];
  const lines = data.lines.map((l) => ({ ...l, productId: matchProduct(state.products, l.description)?.id }));
  const cur = data.currency;

  // 1. Do the numbers add up?
  const sum = lines.reduce((n, l) => n + (l.amount ?? (l.quantity !== null && l.unitPrice !== null ? l.quantity * l.unitPrice : 0)), 0);
  if (data.total !== null && lines.length) {
    const expected = data.subtotal ?? sum;
    if (Math.abs(sum - expected) > 0.02 + expected * 0.001)
      checks.push(`The lines add up to ${fmt(sum, cur)}, but the document says ${fmt(expected, cur)}. Check for a missed line or a typo.`);
    if (data.tax !== null && data.subtotal !== null && Math.abs(data.subtotal + data.tax - data.total) > 0.02)
      checks.push(`Subtotal ${fmt(data.subtotal, cur)} + tax ${fmt(data.tax, cur)} does not equal the total ${fmt(data.total, cur)}.`);
  }

  // 2. Unit prices against what you normally pay (only meaningful in the store's own currency).
  if (!cur || cur === "USD") {
    for (const l of lines) {
      const p = state.products.find((x) => x.id === l.productId);
      const uc = unitCost(l);
      if (!p || uc === null || p.cost <= 0) continue;
      const diff = (uc - p.cost) / p.cost;
      if (Math.abs(diff) > 0.05) checks.push(`${p.name}: billed ${fmt(uc, cur)} per unit vs your recorded cost ${fmt(p.cost, cur)} (${pct(diff)}).`);
    }
  } else if (lines.some((l) => l.productId)) {
    checks.push(`Prices are in ${cur}, but Stock Genie records costs in USD, so they were not compared.`);
  }

  // 3. Against approved purchase orders from the same supplier.
  const issuer = data.issuer;
  if (issuer) {
    const orders = state.orders.filter((o) => o.status === "Approved" && sameParty(issuer, o.supplier));
    for (const o of orders) {
      const bad: string[] = [];
      for (const ol of o.lines) {
        const p = state.products.find((x) => x.id === ol.productId);
        const got = lines.filter((l) => l.productId === ol.productId);
        if (!p) continue;
        const qty = got.reduce((n, l) => n + (unitQty(l) ?? 0), 0);
        if (!got.length) bad.push(`${p.name} (ordered ${ol.quantity}, not on this document)`);
        else if (got.every((l) => l.quantity !== null) && qty !== ol.quantity) bad.push(`${p.name} (ordered ${ol.quantity}, document shows ${qty})`);
      }
      if (bad.length) checks.push(`Compared with ${o.id}: ${bad.join("; ")}.`);
      else if (lines.some((l) => o.lines.some((ol) => ol.productId === l.productId))) checks.push(`Matches the quantities on purchase order ${o.id}.`);
    }
  }

  // 4. Seen before?
  const number = data.number;
  if (number) {
    const dup =
      (state.scans ?? []).some((s) => s.number === number && sameParty(s.issuer ?? "", issuer ?? "")) ||
      (state.documents ?? []).some((d) => (d.number ?? d.reference) === number && issuer && sameParty(d.party, issuer));
    if (dup) checks.push(`Document number ${number} from this supplier is already in your records — possible duplicate.`);
  }

  const unmatched = lines.filter((l) => !l.productId).length;
  if (lines.length && unmatched) checks.push(`${unmatched} of ${lines.length} lines could not be matched to a product in your inventory.`);
  return { lines, checks };
}
