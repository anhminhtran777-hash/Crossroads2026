import { describe, expect, it } from "vitest";
import { checkout, initialState } from "./model";
import { applyRestockPlan, autoRestock, businessInsights, restockPlan } from "./insights";

describe("smart restocking", () => {
  it("rounds to whole stacks and skips products already on an open order", () => {
    const plan = restockPlan(initialState);
    expect(plan.length).toBeGreaterThan(0);
    expect(plan.every((s) => s.quantity % (s.product.caseSize ?? 1) === 0)).toBe(true);
    const onOrder = new Set(["p2", "p4", "p7", "p5", "p14"]);
    expect(plan.every((s) => !onOrder.has(s.product.id))).toBe(true);
  });
  it("creates drafts with unique ids and settles after one pass", () => {
    const t = "2026-10-10T10:00:00.000Z";
    const r = applyRestockPlan(initialState, restockPlan(initialState), "tester", t);
    expect(r.created.length).toBeGreaterThan(0);
    expect(new Set(r.state.orders.map((o) => o.id)).size).toBe(r.state.orders.length);
    expect(autoRestock(r.state, "auto", "2026-10-10T11:00:00.000Z").created).toHaveLength(0);
  });
  it("defers items that exceed the budget", () => {
    expect(restockPlan(initialState, { budgetLeft: 30 }).some((s) => s.deferred)).toBe(true);
  });
});

describe("business insights", () => {
  it("suggests a bundle once receipts show items bought together", () => {
    let s = initialState;
    for (let i = 0; i < 5; i++)
      s = checkout(s, [{ productId: "p1", quantity: 1 }, { productId: "p4", quantity: 1 }], "Card", undefined, "x", `2026-10-10T1${i}:00:00.000Z`, `R${i}`).state;
    expect(businessInsights(s).some((i) => i.id === "bundle")).toBe(true);
  });
});
