import { useMemo, useState } from "react";
import { Check, PackagePlus, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStockPilot } from "./store";
import { categories, type Category } from "./model";
import { addProduct, setPrice } from "./catalog";
import { proposeCostChanges, proposeProducts } from "./proposals";
import type { CompareDoc } from "./compare";

type Edit = { include?: boolean; name?: string; size?: string; category?: Category; price?: string };
const VIA = "from scanned document";

/**
 * Manager-only actions that follow from paperwork: add products the shop doesn't stock yet (price chosen
 * automatically from similar items, editable) and re-price items whose cost changed. Nothing here touches stock.
 */
export function CatalogUpdates({ doc }: { doc: CompareDoc }) {
  const { state, setState, user, role } = useStockPilot();
  const nonUsd = !!doc.currency && doc.currency !== "USD";
  const [rate, setRate] = useState("");
  const rateNum = nonUsd ? Number(rate) : 1;
  const proposals = useMemo(() => proposeProducts(state, doc, rateNum), [state, doc, rateNum]);
  const changes = useMemo(() => proposeCostChanges(state, doc, rateNum), [state, doc, rateNum]);
  const [edits, setEdits] = useState<Record<string, Edit>>({});
  const [skip, setSkip] = useState<Record<string, boolean>>({});
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const edit = (key: string, patch: Edit) => setEdits((e) => ({ ...e, [key]: { ...e[key], ...patch } }));
  const hasLines = doc.lines.some((l) => l.unitPrice !== null);
  if (role !== "Manager" || !hasLines) return null;
  if (!nonUsd && !proposals.length && !changes.length && !msg) return null;

  const addSelected = () => {
    const time = new Date().toISOString();
    let next = state;
    const added: string[] = [];
    const errors: string[] = [];
    for (const p of proposals) {
      const e = edits[p.key] ?? {};
      if (e.include === false) continue;
      const price = e.price !== undefined && e.price !== "" ? Number(e.price) : p.draft.price;
      const res = addProduct(next, { ...p.draft, name: e.name ?? p.draft.name, size: e.size ?? p.draft.size, category: e.category ?? p.draft.category, price }, user, time, VIA);
      if (res.product) {
        next = res.state;
        added.push(`${res.product.name} at $${res.product.price.toFixed(2)}`);
      } else errors.push(`${e.name ?? p.draft.name}: ${res.error}`);
    }
    if (added.length) setState(next);
    setMsg({ ok: errors.length === 0, text: [added.length ? `Added ${added.join("; ")}. Stock is 0 until a delivery is received.` : "", ...errors].filter(Boolean).join(" ") });
  };
  const applyChanges = () => {
    const time = new Date().toISOString();
    let next = state;
    const done: string[] = [];
    for (const c of changes) {
      if (skip[c.key]) continue;
      const res = setPrice(next, c.product.id, c.newPrice, user, time, { cost: c.newCost, via: VIA });
      if (res.product) {
        next = res.state;
        done.push(c.product.name);
      }
    }
    if (done.length) setState(next);
    setMsg({ ok: true, text: done.length ? `Updated cost${done.length > 1 ? "s" : ""} and prices for ${done.join(", ")}.` : "Nothing was changed." });
  };

  return (
    <section className="catalog-updates" aria-label="Catalogue updates">
      {nonUsd && (
        <label className="catalog-rate">
          This document is in {doc.currency}. Stock Genie works in US dollars — enter the exchange rate (1 {doc.currency} = ? USD)
          <input type="number" min="0" step="0.0001" value={rate} onChange={(e) => setRate(e.target.value)} placeholder="e.g. 1.08" />
        </label>
      )}
      {proposals.length > 0 && (
        <div>
          <h3><PackagePlus size={15} className="inline" /> New products on this document</h3>
          <p className="catalog-hint">Not in your inventory yet. Prices are chosen from similar items in your shop (never below a safe margin) — change any you like.</p>
          <div className="scan-table">
            <table>
              <thead><tr><th></th><th>Product</th><th>Size</th><th>Category</th><th>Cost</th><th>Price</th><th>Margin</th></tr></thead>
              <tbody>
                {proposals.map((p) => {
                  const e = edits[p.key] ?? {};
                  const price = e.price !== undefined && e.price !== "" ? Number(e.price) : p.draft.price;
                  const margin = price > 0 ? Math.round(((price - p.draft.cost) / price) * 100) : 0;
                  return (
                    <tr key={p.key}>
                      <td><input type="checkbox" aria-label={`Add ${p.draft.name}`} checked={e.include !== false} onChange={(ev) => edit(p.key, { include: ev.target.checked })} /></td>
                      <td><input className="catalog-input" value={e.name ?? p.draft.name} onChange={(ev) => edit(p.key, { name: ev.target.value })} aria-label="Product name" /></td>
                      <td><input className="catalog-input narrow" value={e.size ?? p.draft.size} onChange={(ev) => edit(p.key, { size: ev.target.value })} aria-label="Size" /></td>
                      <td>
                        <select className="catalog-input" value={e.category ?? p.draft.category} onChange={(ev) => edit(p.key, { category: ev.target.value as Category })} aria-label="Category">
                          {categories.map((c) => <option key={c}>{c}</option>)}
                        </select>
                      </td>
                      <td>${p.draft.cost.toFixed(2)}</td>
                      <td><input className="catalog-input narrow" type="number" step="0.01" min="0" value={e.price ?? String(p.draft.price)} onChange={(ev) => edit(p.key, { price: ev.target.value })} aria-label="Selling price" /></td>
                      <td className={margin < 15 ? "negative" : ""}>{margin}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <p className="catalog-hint">{proposals[0]?.suggestion.basis}</p>
          <div className="flex justify-end"><Button size="sm" onClick={addSelected}><PackagePlus /> Add selected products</Button></div>
        </div>
      )}
      {changes.length > 0 && (
        <div>
          <h3><TrendingUp size={15} className="inline" /> Supplier costs changed</h3>
          <p className="catalog-hint">These products cost a different amount than you have recorded. Update the cost and keep your margin.</p>
          <div className="scan-table">
            <table>
              <thead><tr><th></th><th>Product</th><th>Cost</th><th>Price</th><th>Why</th></tr></thead>
              <tbody>
                {changes.map((c) => (
                  <tr key={c.key}>
                    <td><input type="checkbox" aria-label={`Update ${c.product.name}`} checked={!skip[c.key]} onChange={(ev) => setSkip((s) => ({ ...s, [c.key]: !ev.target.checked }))} /></td>
                    <td>{c.product.name}</td>
                    <td>${c.oldCost.toFixed(2)} → ${c.newCost.toFixed(2)}</td>
                    <td>${c.oldPrice.toFixed(2)} → <strong>${c.newPrice.toFixed(2)}</strong></td>
                    <td className="text-muted-foreground">{c.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex justify-end"><Button size="sm" variant="outline" onClick={applyChanges}>Update costs &amp; prices</Button></div>
        </div>
      )}
      {msg && <p className={`${msg.ok ? "positive" : "negative"} text-sm`} role="status">{msg.ok && <Check size={14} className="inline" />} {msg.text}</p>}
    </section>
  );
}
