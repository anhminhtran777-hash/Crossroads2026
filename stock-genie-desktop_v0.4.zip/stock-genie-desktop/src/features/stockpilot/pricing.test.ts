import { describe, expect, it } from "vitest";
import { initialState } from "./model";
import { addProduct, setPrice } from "./catalog";
import { charm, clampPrice, suggestPrice, suggestReprice } from "./pricing";

const t = "2026-10-11T10:00:00.000Z";

describe("pricing", () => {
  it("suggests a price inside the guard-rails with a shop-style ending", () => {
    const s = suggestPrice(initialState, { name: "Fanta Lemon Zero", category: "Beverages", cost: 0.9 });
    expect(s.price).toBeGreaterThanOrEqual(s.floor);
    expect(s.price).toBeLessThanOrEqual(s.ceiling);
    expect(Math.round(s.price * 100) % 10).toBe(9);
  });
  it("keeps any proposed price (e.g. the AI's) within limits", () => {
    const s = suggestPrice(initialState, { name: "Fanta Lemon Zero", category: "Beverages", cost: 0.9 });
    expect(clampPrice(0.5, s).price).toBeGreaterThanOrEqual(s.floor);
    expect(clampPrice(99, s).price).toBeLessThanOrEqual(s.ceiling);
    expect(clampPrice(s.price, s).adjusted).toBe(false);
    expect(charm(1.8, 1)).toBe(1.79);
  });
  it("only raises prices when cost rises", () => {
    const p = initialState.products.find((x) => x.id === "p5")!;
    expect(suggestReprice(initialState, p, p.cost * 1.2).changed).toBe(true);
    expect(suggestReprice(initialState, p, p.cost * 0.9).changed).toBe(false);
  });
});

describe("catalogue actions", () => {
  const draft = { name: "Fanta Lemon Zero", size: "500 ml", category: "Beverages" as const, cost: 0.9, price: 1.59, supplier: "Coca-Cola Distribution" };
  it("adds a product with unique ids and an audit entry, and rejects duplicates and losses", () => {
    const a = addProduct(initialState, draft, "tester", t, "AI assistant");
    expect(a.product).toBeDefined();
    expect(a.state.activities[0]?.action).toContain("AI assistant");
    expect(addProduct(a.state, { ...draft, name: "fanta  lemon zero", size: "500ml" }, "t", t).error).toContain("already exists");
    expect(addProduct(initialState, { ...draft, price: 0.5 }, "t", t).error).toBeDefined();
    const b = addProduct(a.state, { ...draft, name: "Other", size: "1 l" }, "t", t);
    expect(b.product?.sku).not.toBe(a.product?.sku);
    expect(b.product?.barcode).not.toBe(a.product?.barcode);
  });
  it("refuses prices that lose money", () => {
    expect(setPrice(initialState, "p1", 0.3, "t", t).error).toBeDefined();
    expect(setPrice(initialState, "p1", 2.19, "t", t).product?.price).toBe(2.19);
  });
});
