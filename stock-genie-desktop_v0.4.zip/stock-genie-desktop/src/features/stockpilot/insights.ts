/**
 * Offline business intelligence for Stock Genie.
 *
 * Everything here is a pure function of the store state, so smart restocking, revenue tips and
 * customer-retention warnings keep working with no internet. The AI assistant reads the same
 * results and adds explanation, but never replaces these numbers.
 */
import {
  createPurchaseRequest,
  isLowStock,
  orderCost,
  money,
  restockQuantity,
  type Product,
  type StoreState,
} from "./model";

export const TARGET_COVER_DAYS = 14;
const LOW_COVER_DAYS = 7;

/* ------------------------------ sales speed ------------------------------ */

/** True when the product has any recorded sales in its six-month history. */
export const hasSalesHistory = (p: Product) => p.sold.some((n) => n > 0);

/** Average units sold per day, from the last three monthly totals. 0 when there is no history. */
export function dailyVelocity(p: Product): number {
  const recent = p.sold.slice(-3);
  if (!recent.length) return 0;
  return recent.reduce((n, v) => n + v, 0) / recent.length / 30;
}

/** Days the current stock lasts at the current pace (Infinity when nothing sells). */
export function daysOfCover(p: Product): number {
  const v = dailyVelocity(p);
  return v > 0 ? p.stock / v : Infinity;
}

/** Margin as a share of the selling price (0–1). */
export const marginPct = (p: Product) => (p.price > 0 ? (p.price - p.cost) / p.price : 0);

const round2 = (n: number) => Math.round(n * 100) / 100;
const activeProducts = (state: StoreState) => state.products.filter((p) => !p.archived);

/** Product ids already on an order that is waiting for approval or delivery. */
export function openOrderProductIds(state: StoreState): Set<string> {
  return new Set(state.orders.filter((o) => o.status !== "Received").flatMap((o) => o.lines.map((l) => l.productId)));
}

/* ----------------------------- smart restocking ---------------------------- */

export type RestockSuggestion = {
  product: Product;
  quantity: number;
  stacks: number;
  daysLeft: number;
  cost: number;
  urgency: "out" | "critical" | "low" | "soon";
  reason: string;
  /** True when the budget would be exceeded; deferred items are listed but never ordered automatically. */
  deferred: boolean;
};

const urgencyRank = { out: 0, critical: 1, low: 2, soon: 3 } as const;

/**
 * What to reorder, how much, and in what order. Quantity covers the target number of days of sales
 * (or the store's normal reorder rule when there is no sales history), rounded up to whole wholesale
 * stacks. Products already on an open order are skipped. Optionally respects a spending budget.
 */
export function restockPlan(
  state: StoreState,
  opts: { coverDays?: number; budgetLeft?: number } = {},
): RestockSuggestion[] {
  const cover = opts.coverDays ?? TARGET_COVER_DAYS;
  const covered = openOrderProductIds(state);
  const found: RestockSuggestion[] = [];
  for (const p of activeProducts(state)) {
    if (covered.has(p.id) || !p.supplier.trim()) continue;
    const v = dailyVelocity(p);
    const daysLeft = v > 0 ? p.stock / v : Infinity;
    const low = isLowStock(p);
    if (!low && !(v > 0 && daysLeft < LOW_COVER_DAYS)) continue;
    let qty = v > 0 ? Math.max(Math.ceil(v * cover) - p.stock, 0) : 0;
    if (low) qty = Math.max(qty, restockQuantity(p));
    qty = Math.max(qty, 1);
    const size = p.caseSize && p.caseSize > 0 ? p.caseSize : 1;
    const stacks = Math.ceil(qty / size);
    const quantity = stacks * size;
    const urgency = p.stock <= 0 ? "out" : daysLeft < 3 ? "critical" : low ? "low" : "soon";
    const pace = v > 0 ? `sells about ${round2(v)}/day` : "no sales history yet";
    const reason =
      urgency === "out"
        ? `Out of stock (${pace}).`
        : `${p.stock} left, ${Number.isFinite(daysLeft) ? `about ${Math.max(Math.floor(daysLeft), 0)} day(s) of cover` : "no sales pace known"}; ${pace}.`;
    found.push({ product: p, quantity, stacks, daysLeft, cost: round2(quantity * p.cost), urgency, reason, deferred: false });
  }
  found.sort((a, b) => urgencyRank[a.urgency] - urgencyRank[b.urgency] || a.daysLeft - b.daysLeft || a.product.name.localeCompare(b.product.name));
  if (opts.budgetLeft !== undefined) {
    let spent = 0;
    for (const s of found) {
      if (spent + s.cost <= opts.budgetLeft + 0.001) spent += s.cost;
      else s.deferred = true;
    }
  }
  return found;
}

/** Turns a plan into draft purchase requests (one per supplier). Nothing is approved or charged. */
export function applyRestockPlan(
  state: StoreState,
  plan: RestockSuggestion[],
  actor: string,
  time: string,
): { state: StoreState; created: string[] } {
  const items = plan.filter((s) => !s.deferred);
  const suppliers = [...new Set(items.map((s) => s.product.supplier))];
  let next = state;
  const created: string[] = [];
  suppliers.forEach((supplier, i) => {
    const before = next.orders.length;
    next = createPurchaseRequest(
      next,
      supplier,
      items.filter((s) => s.product.supplier === supplier).map((s) => ({ productId: s.product.id, quantity: s.quantity })),
      actor,
      new Date(Date.parse(time) + i).toISOString(),
    );
    if (next.orders.length > before) created.push(next.orders[0]!.id);
  });
  return { state: next, created };
}

/** Unattended restocking: drafts only (a person still approves), skips anything already on order. */
export function autoRestock(state: StoreState, actor: string, time: string, budgetLeft?: number) {
  const plan = restockPlan(state, budgetLeft === undefined ? {} : { budgetLeft });
  return plan.some((s) => !s.deferred) ? applyRestockPlan(state, plan, actor, time) : { state, created: [] as string[] };
}

/* ------------------------------ sales analysis ------------------------------ */

export type Insight = {
  id: string;
  kind: "revenue" | "retention" | "stock" | "cash";
  severity: "high" | "medium" | "low";
  title: string;
  detail: string;
  impact?: string | undefined;
  productIds?: string[] | undefined;
};

/** Pairs of products that appear on the same receipt, most frequent first. */
export function coPurchasePairs(state: StoreState): { a: string; b: string; count: number }[] {
  const counts = new Map<string, { a: string; b: string; count: number }>();
  for (const d of state.documents ?? []) {
    if (d.kind !== "Receipt") continue;
    const names = [...new Set(d.lines.map((l) => l.name))].sort();
    for (let i = 0; i < names.length; i++)
      for (let j = i + 1; j < names.length; j++) {
        const key = `${names[i]}|${names[j]}`;
        const cur = counts.get(key) ?? { a: names[i]!, b: names[j]!, count: 0 };
        cur.count++;
        counts.set(key, cur);
      }
  }
  return [...counts.values()].sort((x, y) => y.count - x.count);
}

export function refundSummary(state: StoreState) {
  const refunds = state.activities.filter((a) => a.flow === "customer-refund");
  const sales = state.activities.filter((a) => a.flow === "in");
  const amount = refunds.reduce((n, a) => n + (a.amount ?? 0), 0);
  const salesAmount = sales.reduce((n, a) => n + (a.amount ?? 0), 0);
  const byReason: Record<string, number> = {};
  for (const r of refunds) {
    const key = (r.reason ?? "Unspecified").split(" · ")[0]!;
    byReason[key] = (byReason[key] ?? 0) + 1;
  }
  const byProduct: Record<string, number> = {};
  for (const r of refunds) byProduct[r.product] = (byProduct[r.product] ?? 0) + 1;
  return { count: refunds.length, amount: round2(amount), rate: salesAmount > 0 ? amount / salesAmount : 0, byReason, byProduct };
}

const list = (names: string[], max = 4) =>
  names.length <= max ? names.join(", ") : `${names.slice(0, max).join(", ")} and ${names.length - max} more`;

/** Ranked, plain-language findings about revenue, lost sales and customer experience. */
export function businessInsights(state: StoreState): Insight[] {
  const out: Insight[] = [];
  const active = activeProducts(state);
  const selling = active.filter((p) => dailyVelocity(p) > 0);
  const byPace = [...selling].sort((a, b) => dailyVelocity(b) * b.price - dailyVelocity(a) * a.price);

  // 1. Shelves that are empty right now while customers normally buy the item.
  const out0 = selling.filter((p) => p.stock <= 0);
  if (out0.length) {
    const perDay = out0.reduce((n, p) => n + dailyVelocity(p) * p.price, 0);
    out.push({
      id: "stockout",
      kind: "retention",
      severity: "high",
      title: `${out0.length} regular seller${out0.length > 1 ? "s are" : " is"} out of stock`,
      detail: `${list(out0.map((p) => p.name))}. Customers who come for these leave empty-handed — and may not come back.`,
      impact: `About ${money(perDay)} of sales lost per day`,
      productIds: out0.map((p) => p.id),
    });
  }

  // 2. Favourites about to run out.
  const topSellers = byPace.slice(0, 8);
  const closing = topSellers.filter((p) => p.stock > 0 && daysOfCover(p) < LOW_COVER_DAYS);
  if (closing.length) {
    out.push({
      id: "favourites-low",
      kind: "retention",
      severity: closing.some((p) => daysOfCover(p) < 3) ? "high" : "medium",
      title: "Your best sellers are running low",
      detail: `${list(closing.map((p) => `${p.name} (~${Math.max(Math.floor(daysOfCover(p)), 0)} days left)`))}. Reorder before they sell out.`,
      productIds: closing.map((p) => p.id),
    });
  }

  // 3. Price headroom on popular, thin-margin items.
  const thin = byPace.slice(0, 10).filter((p) => marginPct(p) < 0.35).slice(0, 3);
  if (thin.length) {
    const gain = thin.reduce((n, p) => n + dailyVelocity(p) * 30 * p.price * 0.05, 0);
    out.push({
      id: "price-headroom",
      kind: "revenue",
      severity: "medium",
      title: "Popular items with thin margins",
      detail: `${list(thin.map((p) => `${p.name} (${Math.round(marginPct(p) * 100)}% margin)`))}. A 5% price rise on items people buy by habit rarely costs sales.`,
      impact: `About ${money(gain)}/month extra if volume holds`,
      productIds: thin.map((p) => p.id),
    });
  }

  // 4. Cash tied up in slow stock.
  const slow = selling.filter((p) => p.stock > 0 && daysOfCover(p) > 120 && p.stock * p.cost >= 25);
  if (slow.length) {
    const tied = slow.reduce((n, p) => n + p.stock * p.cost, 0);
    out.push({
      id: "overstock",
      kind: "cash",
      severity: "medium",
      title: "Cash is tied up in slow-moving stock",
      detail: `${list(slow.map((p) => p.name))} would take 4+ months to sell. Run a multi-buy offer or pause reordering.`,
      impact: `${money(tied)} sitting on shelves at cost`,
      productIds: slow.map((p) => p.id),
    });
  }

  // 5. Bundles from real receipts.
  const receipts = (state.documents ?? []).filter((d) => d.kind === "Receipt");
  const pair = coPurchasePairs(state)[0];
  if (receipts.length >= 3 && pair && pair.count >= 2) {
    out.push({
      id: "bundle",
      kind: "revenue",
      severity: "low",
      title: "A natural bundle",
      detail: `${pair.a} and ${pair.b} were on the same receipt ${pair.count} times. Shelve them together or offer a small combo price.`,
    });
  }

  // 6. Basket size.
  if (receipts.length >= 5) {
    const avg = receipts.reduce((n, d) => n + d.total, 0) / receipts.length;
    out.push({
      id: "basket",
      kind: "revenue",
      severity: "low",
      title: `Average basket is ${money(avg)}`,
      detail: `A small perk above ${money(Math.ceil(avg * 1.25))} (a free coffee, a discount on the next visit) nudges shoppers to add one more item.`,
    });
  }

  // 7. Refund patterns = quality problems that cost loyalty.
  const rf = refundSummary(state);
  const repeat = Object.entries(rf.byProduct).filter(([, n]) => n >= 2);
  if (repeat.length || rf.rate > 0.05) {
    out.push({
      id: "refunds",
      kind: "retention",
      severity: rf.rate > 0.1 ? "high" : "medium",
      title: "Refunds point to a quality problem",
      detail: repeat.length
        ? `${list(repeat.map(([n, c]) => `${n} (${c}×)`))} keep coming back. Check the batch and talk to the supplier.`
        : `Refunds equal ${(rf.rate * 100).toFixed(1)}% of sales. Look at the most common reasons.`,
      impact: `${money(rf.amount)} refunded`,
    });
  }

  // 8. Money owed by suppliers.
  const open = (state.reports ?? []).filter((r) => r.status === "Open");
  if (open.length) {
    const owed = open.reduce((n, r) => n + r.lines.reduce((m, l) => m + l.quantity * l.unit, 0), 0);
    out.push({
      id: "supplier-issues",
      kind: "cash",
      severity: owed > 100 ? "high" : "medium",
      title: `${open.length} supplier issue${open.length > 1 ? "s" : ""} still open`,
      detail: "Staff reported problems with supplier paperwork. Chase the credit before it is forgotten.",
      impact: owed > 0 ? `Up to ${money(owed)} to recover` : undefined,
    });
  }

  // 9. Always-useful retention note: the app has no customer records yet.
  out.push({
    id: "know-customers",
    kind: "retention",
    severity: "low",
    title: "Know your regulars",
    detail: "Sales are recorded as walk-in customers, so repeat shoppers can’t be tracked yet. A simple stamp card or phone-number loyalty list shows who stopped coming.",
  });

  const sev = { high: 0, medium: 1, low: 2 } as const;
  return out.sort((a, b) => sev[a.severity] - sev[b.severity]);
}

/* --------------------------- context for the AI --------------------------- */

/** A compact, factual picture of the store for the AI. Kept small so requests stay fast and cheap. */
export function buildSnapshot(state: StoreState, ctx: { storeName: string; budgetLeft?: number }) {
  const active = activeProducts(state);
  const rf = refundSummary(state);
  const brief = (p: Product) => ({
    id: p.id,
    name: `${p.name} (${p.size})`,
    category: p.category,
    stock: p.stock,
    reorderPoint: p.threshold,
    price: p.price,
    cost: p.cost,
    marginPct: Math.round(marginPct(p) * 100),
    perDay: round2(dailyVelocity(p)),
    daysLeft: Number.isFinite(daysOfCover(p)) ? Math.floor(daysOfCover(p)) : null,
    supplier: p.supplier,
    caseSize: p.caseSize ?? 1,
  });
  const plan = restockPlan(state, ctx.budgetLeft === undefined ? {} : { budgetLeft: ctx.budgetLeft });
  const top = [...active].filter((p) => dailyVelocity(p) > 0).sort((a, b) => dailyVelocity(b) * b.price - dailyVelocity(a) * a.price).slice(0, 8);
  return {
    store: ctx.storeName,
    today: new Date().toISOString().slice(0, 10),
    currency: "USD",
    totals: {
      activeProducts: active.length,
      units: active.reduce((n, p) => n + p.stock, 0),
      valueAtCost: round2(active.reduce((n, p) => n + p.stock * p.cost, 0)),
      valueAtRetail: round2(active.reduce((n, p) => n + p.stock * p.price, 0)),
      budgetLeft: ctx.budgetLeft === undefined ? null : round2(ctx.budgetLeft),
    },
    restockPlan: plan.slice(0, 15).map((s) => ({ productId: s.product.id, name: s.product.name, orderUnits: s.quantity, stacks: s.stacks, cost: s.cost, urgency: s.urgency, deferredForBudget: s.deferred, note: s.reason })),
    topSellers: top.map(brief),
    lowStock: active.filter(isLowStock).slice(0, 20).map(brief),
    suppliers: [...new Set(active.map((p) => p.supplier).filter(Boolean))],
    categories: ["Beverages", "Snacks", "Dairy", "Bakery", "Produce", "Household"],
    openOrders: state.orders.filter((o) => o.status !== "Received").map((o) => ({ id: o.id, supplier: o.supplier, status: o.status, lines: o.lines.length })),
    recentDocuments: (state.scans ?? []).slice(0, 5).map((x) => ({ id: x.id, type: x.documentType, number: x.number, issuer: x.issuer })),
    refunds: { count: rf.count, amount: rf.amount, byReason: rf.byReason },
    openSupplierIssues: (state.reports ?? []).filter((r) => r.status === "Open").length,
    findings: businessInsights(state).map((i) => ({ severity: i.severity, title: i.title, detail: i.detail, impact: i.impact ?? null })),
    recentActivity: state.activities.slice(0, 12).map((a) => `${a.time.slice(0, 16)} ${a.actor}: ${a.action} — ${a.product}`),
  };
}

/** Purchase budget still available: budget − committed orders + supplier refunds (same rule as the header). */
export function budgetLeft(state: StoreState, budget: number): number {
  const committed = state.orders.reduce((n, o) => n + orderCost(state, o), 0);
  const refunds = state.activities.filter((a) => a.flow === "refund").reduce((n, a) => n + (a.amount ?? 0), 0);
  return budget - committed + refunds;
}
