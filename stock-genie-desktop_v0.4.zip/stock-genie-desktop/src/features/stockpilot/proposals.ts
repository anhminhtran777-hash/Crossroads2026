/** Turns paperwork lines into catalogue changes: new products (auto-priced) and cost-change repricing. */
import { categories, type Category, type Product, type StoreState } from "./model";
import { asCategory, canonicalSupplier, extractSize, guessCategory, type ProductDraft } from "./catalog";
import { suggestPrice, suggestReprice, type PriceSuggestion } from "./pricing";
import { matchProduct, unitCost, type ScanLine } from "./scan-checks";
import type { CompareDoc } from "./compare";

export type NewProductProposal = { key: string; line: ScanLine; draft: ProductDraft; suggestion: PriceSuggestion };
export type CostChangeProposal = { key: string; product: Product; oldCost: number; newCost: number; oldPrice: number; newPrice: number; note: string };

/** Splits a printed description into a clean name and pack size. */
export function cleanName(l: ScanLine): { name: string; size: string } {
  const size = (l.size ?? "").trim() || extractSize(l.description);
  let name = (l.name ?? "").trim() || l.description.trim();
  if (size) name = name.replace(new RegExp(size.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/ /g, "\\s?"), "i"), "").replace(/\s{2,}/g, " ").trim();
  return { name: name || l.description.trim(), size };
}

/** `rate` converts the document's currency to the shop's (USD); 1 when the document is already in USD. */
export function proposeProducts(state: StoreState, doc: CompareDoc, rate: number): NewProductProposal[] {
  const supplier = canonicalSupplier(state, doc.issuer ?? "");
  return doc.lines.flatMap((l, i): NewProductProposal[] => {
    if ((l.productId ?? matchProduct(state.products, l.description)?.id) !== undefined) return [];
    const uc = unitCost(l);
    if (uc === null || !(uc > 0) || !(rate > 0)) return [];
    const { name, size } = cleanName(l);
    const category: Category = asCategory(l.category) ?? guessCategory(`${name} ${size}`);
    const cost = Math.round(uc * rate * 100) / 100;
    const suggestion = suggestPrice(state, { name, category, cost, supplier });
    return [{ key: `new-${i}`, line: l, suggestion, draft: { name, size, category, cost, price: suggestion.price, supplier, ...(l.barcode ? { barcode: l.barcode } : {}) } }];
  });
}

export function proposeCostChanges(state: StoreState, doc: CompareDoc, rate: number): CostChangeProposal[] {
  if (!(rate > 0)) return [];
  const seen = new Set<string>();
  return doc.lines.flatMap((l, i): CostChangeProposal[] => {
    const p = state.products.find((x) => x.id === (l.productId ?? matchProduct(state.products, l.description)?.id));
    const uc = unitCost(l);
    if (!p || uc === null || p.cost <= 0 || seen.has(p.id)) return [];
    const newCost = Math.round(uc * rate * 100) / 100;
    if (Math.abs(newCost - p.cost) / p.cost <= 0.05) return [];
    seen.add(p.id);
    const r = suggestReprice(state, p, newCost);
    return [{ key: `cost-${i}`, product: p, oldCost: p.cost, newCost, oldPrice: p.price, newPrice: r.price, note: r.note }];
  });
}

export const categoryList = categories;
