import { Sparkles, PackagePlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useStockPilot } from "./store";
import { applyRestockPlan, budgetLeft as budgetLeftOf, businessInsights, restockPlan } from "./insights";
import { money } from "./model";

/** Dashboard card: restock plan and the most valuable findings. Computed on this PC, so it works offline. */
export function InsightsPanel() {
  const { state, setState, user, budget } = useStockPilot();
  const [note, setNote] = useState("");
  const plan = restockPlan(state, { budgetLeft: budgetLeftOf(state, budget) });
  const ready = plan.filter((s) => !s.deferred);
  const cost = ready.reduce((n, s) => n + s.cost, 0);
  const insights = businessInsights(state).slice(0, 5);
  return (
    <section className="dashboard-section mb-6">
      <div className="section-heading">
        <h2><Sparkles size={16} className="inline" /> Smart insights</h2>
        <span className="demo-label">Works offline</span>
      </div>
      <div className="insight-restock">
        <div>
          <strong>{plan.length ? `${plan.length} product${plan.length > 1 ? "s" : ""} to reorder` : "Nothing to reorder right now"}</strong>
          <span>{plan.length ? `${ready.length} ready to draft · ${money(cost)}${plan.length > ready.length ? ` · ${plan.length - ready.length} over budget` : ""}` : "Stock is healthy or already on order."}</span>
        </div>
        <Button
          size="sm"
          disabled={!ready.length}
          onClick={() => {
            const r = applyRestockPlan(state, plan, user, new Date().toISOString());
            if (r.created.length) {
              setState(r.state);
              setNote(`Created ${r.created.join(", ")} — review them in Purchase Orders.`);
            }
          }}
        >
          <PackagePlus /> Draft restock orders
        </Button>
      </div>
      {note && <p className="positive text-sm mt-2" role="status">{note}</p>}
      <ul className="insight-list">
        {insights.map((i) => (
          <li key={i.id} data-severity={i.severity}>
            <i aria-hidden="true" />
            <div>
              <strong>{i.title}</strong>
              <span>{i.detail}</span>
              {i.impact && <small>{i.impact}</small>}
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
