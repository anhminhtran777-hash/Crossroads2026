import { catalogueCaseSize, categories, ean13, type Category, type Product, type StoreState } from "./model";
import { MIN_MARKUP } from "./pricing";
import { sameParty, tokens } from "./scan-checks";

export type ProductDraft = {
  name: string;
  size: string;
  category: Category;
  cost: number;
  price: number;
  supplier: string;
  stock?: number | undefined;
  threshold?: number | undefined;
  caseSize?: number | undefined;
  barcode?: string | undefined;
};

const emoji: Record<Category, string> = { Beverages: "🥤", Snacks: "🍪", Dairy: "🥛", Bakery: "🍞", Produce: "🍎", Household: "🧴" };
const norm = (s: string) => tokens(s).join(" ");
const normSize = (s: string) => s.toLowerCase().replace(/[\s.,]/g, "");

export const asCategory = (v: unknown): Category | undefined => categories.find((c) => c.toLowerCase() === String(v ?? "").trim().toLowerCase());

/** Uses the exact supplier spelling already in your inventory when the name clearly refers to the same company. */
export function canonicalSupplier(state: StoreState, name: string): string {
  const n = name.trim();
  const known = [...new Set(state.products.map((p) => p.supplier).filter(Boolean))];
  return known.find((k) => k.toLowerCase() === n.toLowerCase()) ?? known.find((k) => n && sameParty(n, k) && sameParty(k, n)) ?? n;
}

/** Best-effort category when the scanner didn't give one. */
export function guessCategory(text: string): Category {
  const t = text.toLowerCase();
  if (/milk|yogh?urt|cheese|butter|cream|kefir|mlyako|мляко|сирене|кисело/.test(t)) return "Dairy";
  if (/bread|bun|croissant|baguette|cake|pastry|хляб/.test(t)) return "Bakery";
  if (/apple|banana|orange|tomato|cucumber|fruit|vegetable|potato|ябълк|банан/.test(t)) return "Produce";
  if (/detergent|dishwash|soap|shampoo|tissue|toilet|bleach|cleaner|sponge|paper towel|препарат/.test(t)) return "Household";
  if (/cola|fanta|sprite|water|juice|soda|beer|wine|vodka|coffee|tea|lemonade|energy|вода|сок/.test(t)) return "Beverages";
  return "Snacks";
}

/** Pulls a pack size such as "500 ml" or "50 g" out of a printed description. */
export function extractSize(text: string): string {
  const m = /(\d+(?:[.,]\d+)?)\s?(ml|cl|l|g|kg|oz|pcs?|pack)\b/i.exec(text);
  return m ? `${m[1]!.replace(",", ".")} ${m[2]!.toLowerCase()}` : "";
}

export type AddResult = { state: StoreState; product?: Product; error?: string };

/** Adds a product exactly as the "New product" form would, with unique id/SKU/barcode and an audit entry. */
export function addProduct(state: StoreState, d: ProductDraft, actor: string, time: string, via?: string): AddResult {
  const name = d.name.trim();
  const supplier = d.supplier.trim();
  if (!name) return { state, error: "A product needs a name." };
  if (!supplier) return { state, error: "A product needs a supplier so it can be reordered." };
  if (!(d.cost > 0)) return { state, error: "The cost must be greater than zero." };
  if (!(d.price >= d.cost)) return { state, error: "The selling price must be at least the cost." };
  if (!categories.includes(d.category)) return { state, error: "Unknown category." };
  const dup = state.products.find((p) => norm(p.name) === norm(name) && normSize(p.size) === normSize(d.size));
  if (dup) return { state, error: `“${dup.name}${dup.size ? ` (${dup.size})` : ""}” already exists${dup.archived ? " (archived)" : ""}.` };
  const used = new Set(state.products.flatMap((p) => [p.barcode, ...(p.barcodes ?? [])]));
  let barcode = (d.barcode ?? "").replace(/\D/g, "");
  if (barcode && used.has(barcode)) return { state, error: `Barcode ${barcode} already belongs to another product.` };
  if (!barcode) {
    let n = 1;
    do barcode = ean13(`298${String(n++).padStart(9, "0")}`);
    while (used.has(barcode));
  }
  const ids = new Set(state.products.map((p) => p.id));
  let id = `p-${Date.parse(time) || Date.now()}`;
  for (let i = 2; ids.has(id); i++) id = `p-${Date.parse(time) || Date.now()}-${i}`;
  const skuNum = state.products.reduce((m, p) => Math.max(m, Number(/^SP-(\d+)$/.exec(p.sku)?.[1] ?? 0)), 1000) + 1;
  const stock = Number.isSafeInteger(d.stock) && (d.stock ?? 0) > 0 ? d.stock! : 0;
  const caseSize = d.caseSize && Number.isSafeInteger(d.caseSize) && d.caseSize > 0 ? d.caseSize : d.category === "Beverages" ? catalogueCaseSize(d.size) : 12;
  const product: Product = {
    id,
    name,
    size: d.size.trim(),
    category: d.category,
    stock,
    threshold: d.threshold && Number.isSafeInteger(d.threshold) && d.threshold >= 0 ? d.threshold : 12,
    price: Math.round(d.price * 100) / 100,
    cost: Math.round(d.cost * 100) / 100,
    supplier,
    sku: `SP-${skuNum}`,
    barcode,
    caseSize,
    emoji: emoji[d.category],
    history: Array(6).fill(stock),
    received: Array(6).fill(0),
    sold: Array(6).fill(0),
  };
  return {
    product,
    state: {
      ...state,
      products: [...state.products, product],
      activities: [{ id: `${time}-${id}-created`, product: name, actor, action: via ? `Product created (${via})` : "Product created", after: stock, time }, ...state.activities],
    },
  };
}

/** Changes a selling price (and optionally the recorded cost) with an audit entry. Refuses prices that lose money. */
export function setPrice(
  state: StoreState,
  productId: string,
  price: number,
  actor: string,
  time: string,
  opts: { cost?: number; via?: string } = {},
): AddResult {
  const p = state.products.find((x) => x.id === productId);
  if (!p) return { state, error: "Product not found." };
  const cost = opts.cost !== undefined ? opts.cost : p.cost;
  if (!(cost > 0) || !(price >= cost * MIN_MARKUP * 0.95)) return { state, error: `A price of ${price.toFixed(2)} is too close to the cost (${cost.toFixed(2)}).` };
  const next: Product = { ...p, price: Math.round(price * 100) / 100, cost: Math.round(cost * 100) / 100 };
  return {
    product: next,
    state: {
      ...state,
      products: state.products.map((x) => (x.id === p.id ? next : x)),
      activities: [
        {
          id: `${time}-${p.id}-price`,
          product: p.name,
          actor,
          action: `Price updated ${p.price.toFixed(2)} → ${next.price.toFixed(2)}${opts.cost !== undefined ? `, cost ${p.cost.toFixed(2)} → ${next.cost.toFixed(2)}` : ""}${opts.via ? ` (${opts.via})` : ""}`,
          time,
        },
        ...state.activities,
      ],
    },
  };
}
