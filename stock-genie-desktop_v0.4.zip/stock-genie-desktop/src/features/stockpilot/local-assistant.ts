import { isLowStock, money, type StoreState } from "./model";
import { businessInsights, restockPlan, type Insight } from "./insights";

const bullets = (items: Insight[]) => items.map((i) => `- **${i.title}.** ${i.detail}${i.impact ? ` _(${i.impact})_` : ""}`).join("\n");

/**
 * Offline "hands": the few everyday commands that can be carried out without the AI, using the very same
 * tools. Returns the reply, or null when the message is not a command (then localAnswer takes over).
 */
export function localAct(text: string, run: (name: string, input: Record<string, unknown>) => string, state: StoreState): string | null {
  const t = text.toLowerCase();
  const call = (name: string, input: Record<string, unknown> = {}) => JSON.parse(run(name, input)) as Record<string, unknown>;
  if (/\b(approve|authori[sz]e|sign off)\b/.test(t) && /order|purchase|request|draft|everything|all/.test(t)) {
    const ids = state.orders.filter((o) => o.status === "Draft").map((o) => o.id);
    if (!ids.length) return "There are no drafts waiting for approval.";
    const r = call("request_order_approval", { order_ids: ids });
    return r["error"] ? String(r["error"]) : `I’ve put ${ids.length === 1 ? "the draft" : `all ${ids.length} drafts`} in one approval card below. Nothing is ordered until you click **Approve**.`;
  }
  if (/\b(receive|accept|arrived|delivered|delivery came|got the delivery)\b/.test(t) && !/compare|check|missing|short/.test(t)) {
    const ids = state.orders.filter((o) => o.status === "Approved").map((o) => o.id);
    if (!ids.length) return "No approved orders are waiting for a delivery.";
    const r = call("request_delivery_acceptance", { order_ids: ids });
    return r["error"] ? String(r["error"]) : `Accepting the delivery for ${ids.join(", ")} adds the goods to your stock. Please confirm in the card below.`;
  }
  if (/\b(create|make|prepare|draft|put together|place)\b/.test(t) && /(reorder|restock|order|draft)/.test(t) && !/product/.test(t)) {
    const r = call("create_restock_drafts");
    const created = (r["created"] as string[] | undefined) ?? [];
    if (!created.length) return String(r["note"] ?? "Nothing to draft right now.");
    const ids = created;
    const a = call("request_order_approval", { order_ids: ids });
    return `Drafted **${ids.join(", ")}** from your sales pace.${a["error"] ? "" : " Approve them in the card below when you’re happy."}`;
  }
  return null;
}

/** Offline answers built from the store's own numbers. Used whenever the AI is unreachable or not set up. */
export function localAnswer(text: string, state: StoreState, budgetLeft?: number): string {
  const active = state.products.filter((p) => !p.archived);
  const low = state.products.filter(isLowStock);
  const insights = businessInsights(state);
  if (/(add|create|new).*(product|item)|(change|set|update|raise|lower).*price/i.test(text))
    return "Adding products and changing prices by chat needs the AI, which is unavailable right now. You can add a product in **Inventory → New product**, and the **Smart insights** panel on the dashboard shows pricing opportunities that work offline.";
  if (/compare|delivery|invoice|missing|short|paperwork/i.test(text) && !/reorder|restock/i.test(text))
    return "Open **Documents → Compare a request with paperwork**. It works offline: pick a delivery note or invoice (three ready-made examples are included) and it lists missing, short, extra and re-priced items, with a message you can send to the supplier. Asking the assistant to do this and to add new products from the paperwork needs the AI connection.";
  if (/tip|revenue|improv|grow|sales|margin|price|promo/i.test(text) && !/reorder|restock/i.test(text)) {
    const top = insights.filter((i) => i.kind === "revenue" || i.kind === "cash");
    return top.length
      ? `Here is where I see the most room to earn more:\n\n${bullets(top)}\n\n_Calculated on this PC from your own sales data._`
      : "Nothing stands out yet. Record more sales and I’ll look for pricing and bundle opportunities.";
  }
  if (/customer|client|retain|retention|loyal|lose|losing|regular/i.test(text)) {
    const r = insights.filter((i) => i.kind === "retention");
    return `Customers rarely complain — they just stop coming. These are the things most likely to cost you regulars:\n\n${bullets(r)}\n\n_Connect to the internet and add an API key to get tailored ideas from the AI assistant._`;
  }
  if (/value|cost|profit/i.test(text))
    return `Your current inventory is worth **${money(active.reduce((n, p) => n + p.stock * p.cost, 0))} at cost**, with a retail value of **${money(active.reduce((n, p) => n + p.stock * p.price, 0))}**. Beverages hold the most units. Prioritize replenishing fast-moving essentials before adding slow-moving stock.`;
  if (/reorder|restock|low|order|plan/i.test(text)) {
    const plan = restockPlan(state, budgetLeft === undefined ? {} : { budgetLeft });
    if (!plan.length)
      return low.length
        ? "All low-stock products already have an open purchase order. Review the existing drafts in Purchase Orders."
        : "All active products are above their reorder points. No replenishment is needed right now.";
    const shown = plan.slice(0, 12);
    return `**${plan.length} products need attention.** Quantities cover about two weeks of sales, in whole wholesale stacks:\n\n${shown.map((s) => `- **${s.product.name}**: ${s.reason} Order **${s.quantity} units** (${s.stacks} stack${s.stacks > 1 ? "s" : ""}) from ${s.product.supplier} — ${money(s.cost)}${s.deferred ? " _(over budget — deferred)_" : ""}.`).join("\n")}${plan.length > shown.length ? `\n- …and ${plan.length - shown.length} more.` : ""}\n\nUse **Create reorder drafts** to prepare these for approval.`;
  }
  const units = active.reduce((n, p) => n + p.stock, 0);
  return `Your store currently has **${units} units** across **${active.length} products**, and **${low.length} are at or below their reorder point.**\n\n${insights.slice(0, 3).length ? `What stands out:\n\n${bullets(insights.slice(0, 3))}` : ""}\n\n_Offline summary from your inventory data._`;
}
