import { describe, expect, it } from "vitest";
import { initialState } from "./model";
import { checkScan, parseScanJson } from "./scan-checks";

const json = '```json\n{"documentType":"Supplier invoice","issuer":"Metro Wholesale","number":"INV-77","currency":"USD","lines":[{"description":"Snickers 50 g bar","quantity":40,"unitPrice":"0.80","amount":32},{"description":"Mystery item","quantity":1,"unitPrice":1,"amount":1}],"subtotal":50,"total":50,"summary":"x","warnings":[]}\n```';

describe("scan checks", () => {
  it("parses fenced JSON and rejects text without a document", () => {
    expect(parseScanJson(json)?.lines).toHaveLength(2);
    expect(parseScanJson("no json")).toBeNull();
  });
  it("flags arithmetic, price and order mismatches", () => {
    const { lines, checks } = checkScan(parseScanJson(json)!, initialState);
    expect(lines[0]?.productId).toBe("p5");
    expect(checks.some((c) => c.includes("add up"))).toBe(true);
    expect(checks.some((c) => c.includes("Snickers") && c.includes("cost"))).toBe(true);
    expect(checks.some((c) => c.includes("PO-1040"))).toBe(true);
  });
});
