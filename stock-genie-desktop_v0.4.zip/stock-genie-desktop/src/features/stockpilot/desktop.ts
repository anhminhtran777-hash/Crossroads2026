import { useEffect, useState } from "react";

/** The small API the Windows shell exposes (see electron/preload.cjs). Undefined in a plain browser. */
export type AiResult<T = unknown> = { ok: true; data: T } | { ok: false; code?: string; error: string };
export type StockGenieBridge = {
  isDesktop: true;
  platform: string;
  storage: {
    loadSync: () => Record<string, string> | null;
    save: (snapshot: Record<string, string>) => Promise<boolean>;
    saveSync: (snapshot: Record<string, string>) => boolean;
    exportTo: () => Promise<{ ok: boolean; canceled?: boolean; path?: string; error?: string }>;
    importFrom: () => Promise<{ ok: boolean; canceled?: boolean; error?: string }>;
  };
  ai: {
    status: () => Promise<{ hasKey: boolean; model: string; encryptionAvailable: boolean }>;
    setKey: (key: string) => Promise<{ ok: boolean; error?: string }>;
    clearKey: () => Promise<{ ok: boolean }>;
    setModel: (model: string) => Promise<{ ok: boolean; error?: string }>;
    request: (payload: Record<string, unknown>) => Promise<AiResult<unknown>>;
  };
  app: {
    info: () => Promise<{ version: string; dataFolder: string; electron: string }>;
    openDataFolder: () => Promise<string>;
  };
  log: (level: string, message: string) => void;
};

declare global {
  interface Window {
    stockGenie?: StockGenieBridge;
  }
}

export const bridge = (): StockGenieBridge | undefined => (typeof window === "undefined" ? undefined : window.stockGenie);

/** Live online/offline flag. Only the AI features depend on it. */
export function useOnline(): boolean {
  const [online, setOnline] = useState(() => (typeof navigator === "undefined" ? true : navigator.onLine));
  useEffect(() => {
    const up = () => setOnline(true);
    const down = () => setOnline(false);
    window.addEventListener("online", up);
    window.addEventListener("offline", down);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", down);
    };
  }, []);
  return online;
}

/** Whether an API key is saved (the key itself never leaves the desktop shell). */
export function useAiStatus(refreshKey = 0) {
  const [status, setStatus] = useState<{ hasKey: boolean; model: string; encryptionAvailable: boolean } | null>(null);
  useEffect(() => {
    let live = true;
    const b = bridge();
    if (!b) {
      setStatus({ hasKey: false, model: "", encryptionAvailable: false });
      return;
    }
    void b.ai.status().then((s) => live && setStatus(s));
    return () => {
      live = false;
    };
  }, [refreshKey]);
  return status;
}
