import { describe, expect, it } from "vitest";
import { createPurchaseRequest, initialState } from "./model";
import { buildBriefing } from "./briefing";

describe("opening briefing", () => {
  it("offers one approval for all drafts and one for approved orders — managers only", () => {
    const drafted = createPurchaseRequest(initialState, "Metro Wholesale", [{ productId: "p5", quantity: 24 }], "Tester", "2026-01-05T10:00:00.000Z");
    const m = buildBriefing(drafted, { name: "Mia", role: "Manager", date: new Date("2026-01-05T09:00:00") });
    expect(m.text).toContain("Good morning, Mia.");
    expect(m.requests.some((r) => r.kind === "approve_orders")).toBe(true);
    const s = buildBriefing(drafted, { name: "Sam", role: "Staff" });
    expect(s.requests).toHaveLength(0);
    expect(s.text).toContain("A manager has to give the OK");
  });
  it("says so when there is nothing to do", () => {
    const calm = { ...initialState, products: initialState.products.map((p) => ({ ...p, stock: p.threshold + 50 })), orders: [], reports: [] };
    const b = buildBriefing(calm, { name: "Mia", role: "Manager" });
    expect(b.requests).toHaveLength(0);
  });
});
