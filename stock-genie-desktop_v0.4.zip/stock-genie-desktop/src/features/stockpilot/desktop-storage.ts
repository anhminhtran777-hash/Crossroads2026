import { bridge } from "./desktop";

const PREFIX = "stockgenie:";

function snapshot(): Record<string, string> {
  const out: Record<string, string> = {};
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(PREFIX)) out[k] = localStorage.getItem(k) ?? "";
  }
  return out;
}

/**
 * Mirrors everything the app saves to a file in the Windows profile (with rolling backups) so data
 * survives cache clears and can be exported. The file is the source of truth at start-up.
 * Does nothing in a plain browser, where localStorage alone is used exactly as before.
 */
export function installDiskMirror() {
  const b = bridge();
  if (!b || typeof localStorage === "undefined") return;
  let saved: Record<string, string> | null = null;
  try {
    saved = b.storage.loadSync();
    if (saved) {
      for (const k of Object.keys(snapshot())) localStorage.removeItem(k);
      for (const [k, v] of Object.entries(saved)) localStorage.setItem(k, v);
    }
  } catch (e) {
    b.log("error", `restore failed: ${String(e)}`);
  }
  let timer: ReturnType<typeof setTimeout> | undefined;
  const flush = () => {
    timer = undefined;
    void b.storage.save(snapshot());
  };
  const schedule = () => {
    if (timer === undefined) timer = setTimeout(flush, 400);
  };
  const proto = Storage.prototype;
  const setItem = proto.setItem;
  const removeItem = proto.removeItem;
  proto.setItem = function (this: Storage, key: string, value: string) {
    setItem.call(this, key, value);
    if (this === localStorage && key.startsWith(PREFIX)) schedule();
  };
  proto.removeItem = function (this: Storage, key: string) {
    removeItem.call(this, key);
    if (this === localStorage && key.startsWith(PREFIX)) schedule();
  };
  // Never lose the last change when the window closes.
  window.addEventListener("pagehide", () => {
    if (timer !== undefined) {
      clearTimeout(timer);
      b.storage.saveSync(snapshot());
    }
  });
  if (!saved && Object.keys(snapshot()).length) schedule();
}
