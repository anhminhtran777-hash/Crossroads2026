/** The assistant's opening report when the app starts. Built offline from the store's own numbers. */
import { isLowStock, money, orderCost, type Role, type StoreState } from "./model";
import { businessInsights } from "./insights";
import type { AuthRequest } from "./authorizations";

export type Briefing = { text: string; requests: AuthRequest[]; allClear: boolean };

const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

export function greeting(name: string, date = new Date()): string {
  const h = date.getHours();
  const part = h < 5 ? "Hello" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
  return `${part}, ${name}.`;
}

export function buildBriefing(state: StoreState, opts: { name: string; role: Role; autoDrafted?: string[]; date?: Date }): Briefing {
  const active = state.products.filter((p) => !p.archived);
  const low = active.filter(isLowStock);
  const empty = active.filter((p) => p.stock <= 0 && p.history.some(Boolean));
  const drafts = state.orders.filter((o) => o.status === "Draft");
  const approved = state.orders.filter((o) => o.status === "Approved");
  const issues = (state.reports ?? []).filter((r) => r.status === "Open");
  const top = businessInsights(state).find((i) => i.severity === "high");
  const manager = opts.role === "Manager";
  const lines: string[] = [];

  if (low.length) lines.push(`**${plural(low.length, "product")}** ${low.length === 1 ? "is" : "are"} at or below the reorder point${empty.length ? ` (${empty.length} already empty)` : ""}.`);
  if (opts.autoDrafted?.length) lines.push(`I **prepared ${plural(opts.autoDrafted.length, "purchase request")}** on my own (${opts.autoDrafted.join(", ")}), sized from your sales pace.`);
  if (drafts.length) lines.push(`**${plural(drafts.length, "purchase request")}** ${drafts.length === 1 ? "is" : "are"} drafted and ready, worth ${money(drafts.reduce((n, o) => n + orderCost(state, o), 0))}.`);
  if (approved.length) lines.push(`**${plural(approved.length, "order")}** ${approved.length === 1 ? "is" : "are"} approved and waiting for the delivery to be accepted.`);
  if (issues.length) lines.push(`**${plural(issues.length, "supplier issue")}** ${issues.length === 1 ? "is" : "are"} still open.`);
  if (top) lines.push(`Worth knowing: ${top.title.charAt(0).toLowerCase()}${top.title.slice(1)}${top.impact ? ` — ${top.impact.charAt(0).toLowerCase()}${top.impact.slice(1)}` : ""}.`);

  const requests: AuthRequest[] = [];
  if (manager && drafts.length) requests.push({ kind: "approve_orders", orderIds: drafts.map((o) => o.id) });
  if (manager && approved.length) requests.push({ kind: "receive_orders", orderIds: approved.map((o) => o.id) });

  const allClear = !lines.length;
  const body = allClear
    ? "Everything is in order — nothing needs your attention right now."
    : `Here is where the store stands:\n\n${lines.map((l) => `- ${l}`).join("\n")}`;
  const tail = requests.length
    ? "\n\nEverything else is handled. These are the only things that need your OK:"
    : !manager && (drafts.length || approved.length)
      ? "\n\nA manager has to give the OK on the orders above. Everything else I can handle for you."
      : "\n\nTell me what you need — I can order stock, add products, ring up sales, check delivery notes and more.";
  return { text: `${greeting(opts.name, opts.date)} ${body}${tail}`, requests, allClear };
}
