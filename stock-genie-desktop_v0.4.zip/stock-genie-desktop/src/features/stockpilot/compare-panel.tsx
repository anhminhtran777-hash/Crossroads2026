import { useMemo, useState } from "react";
import { CircleCheck, ClipboardCopy, GitCompareArrows, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStockPilot } from "./store";
import { compareRequest, docFromScan, docFromStoreDocument, exampleDocs, suggestOrder, supplierMessage, type CompareDoc, type Comparison, type RowStatus } from "./compare";
import { CatalogUpdates } from "./catalog-updates";

const badge: Record<RowStatus, { label: string; cls: string }> = {
  ok: { label: "Matches", cls: "ok" },
  short: { label: "Short", cls: "warn" },
  missing: { label: "Missing", cls: "bad" },
  over: { label: "More than requested", cls: "warn" },
  extra: { label: "Not requested", cls: "info" },
};

export function ComparisonView({ comparison: c }: { comparison: Comparison }) {
  const { storeName } = useStockPilot();
  const [copied, setCopied] = useState(false);
  const message = supplierMessage(c, storeName);
  const problems = c.counts.short + c.counts.missing + c.counts.over + c.counts.extra + c.counts.priceFlags;
  return (
    <div className="compare-view">
      <div className={`compare-verdict ${c.complete ? "ok" : "bad"}`} role="status">
        {c.complete ? <CircleCheck size={18} /> : <TriangleAlert size={18} />}
        <div>
          <strong>{c.complete ? "Everything you requested arrived as expected." : `${problems || c.issues.length} thing${(problems || c.issues.length) === 1 ? "" : "s"} to check`}</strong>
          <span>
            {c.order.id} · {c.order.supplier} vs {c.doc.label}
            {c.documentValue !== null ? ` · requested ≈ $${c.requestedValue.toFixed(2)}, document ${c.doc.currency && c.doc.currency !== "USD" ? `${c.documentValue.toFixed(2)} ${c.doc.currency}` : `$${c.documentValue.toFixed(2)}`}` : ""}
          </span>
        </div>
      </div>
      <div className="scan-table">
        <table>
          <thead><tr><th>Product</th><th>Requested</th><th>On document</th><th>Result</th></tr></thead>
          <tbody>
            {c.rows.map((r) => (
              <tr key={r.key}>
                <td>{r.name}{r.isNew && <small className="compare-new"> new product</small>}</td>
                <td>{r.status === "extra" ? "—" : r.requested}</td>
                <td>{r.received}</td>
                <td>
                  <span className={`compare-badge ${badge[r.status].cls}`}>{badge[r.status].label}</span>
                  {r.priceDiffPct !== null && Math.abs(r.priceDiffPct) > 0.05 && <span className="compare-badge warn">Price {r.priceDiffPct > 0 ? "+" : ""}{(r.priceDiffPct * 100).toFixed(0)}%</span>}
                  {r.note && <small className="compare-note">{r.note}</small>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {c.issues.some((i) => i.startsWith("The document is from") || i.startsWith("Document total")) && (
        <ul className="scan-flags">
          {c.issues.filter((i) => i.startsWith("The document is from") || i.startsWith("Document total")).map((i) => <li key={i}><TriangleAlert size={14} />{i}</li>)}
        </ul>
      )}
      {message && (
        <div className="flex justify-end">
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              void navigator.clipboard?.writeText(message).then(() => setCopied(true));
            }}
          >
            <ClipboardCopy /> {copied ? "Copied — paste it into an email" : "Copy a message to the supplier"}
          </Button>
        </div>
      )}
    </div>
  );
}

/** Pick (or auto-pick) the request that belongs to a document and see the comparison. */
export function CompareWithRequest({ doc, initialOrderId }: { doc: CompareDoc; initialOrderId?: string | undefined }) {
  const { state } = useStockPilot();
  const [orderId, setOrderId] = useState(() => initialOrderId ?? suggestOrder(state, doc)?.id ?? "");
  const order = state.orders.find((o) => o.id === orderId);
  const comparison = useMemo(() => (order ? compareRequest(state, order, doc) : null), [state, order, doc]);
  return (
    <div className="compare-with">
      <label className="compare-select">
        <span>Compare with request</span>
        <select value={orderId} onChange={(e) => setOrderId(e.target.value)}>
          <option value="">Choose a request…</option>
          {state.orders.map((o) => <option key={o.id} value={o.id}>{o.id} · {o.supplier} · {o.status} · {o.lines.length} item{o.lines.length > 1 ? "s" : ""}</option>)}
        </select>
      </label>
      {comparison ? <ComparisonView comparison={comparison} /> : <p className="catalog-hint">No matching request found — pick one above, or add the new products below.</p>}
      <CatalogUpdates doc={doc} />
    </div>
  );
}

type Item = { id: string; group: string; label: string; doc: CompareDoc; orderId?: string | undefined };

/** Documents tab: compare any request with a delivery note or invoice. Ready-made examples work offline. */
export function ComparePanel() {
  const { state } = useStockPilot();
  const [open, setOpen] = useState(true);
  const items = useMemo<Item[]>(() => {
    const ex = exampleDocs(state).map((e) => ({ id: e.id, group: "Examples (sample paperwork, not saved)", label: `${e.title} — vs ${e.orderId}`, doc: e.doc, orderId: e.orderId }));
    const scans = (state.scans ?? []).map((s) => ({ id: s.id, group: "Your scanned documents", label: `${s.documentType} ${s.number ?? ""} · ${s.issuer ?? "unknown issuer"}`.trim(), doc: docFromScan(s) }));
    const docs = (state.documents ?? [])
      .filter((d) => d.kind === "Invoice" || d.kind === "Delivery note" || d.kind === "Goods receipt")
      .map((d) => ({ id: d.id, group: "Documents in this shop", label: `${d.kind} ${d.number ?? d.reference} · ${d.party}`, doc: docFromStoreDocument(d, state) }));
    return [...ex, ...scans, ...docs];
  }, [state]);
  const [pick, setPick] = useState(items[0]?.id ?? "");
  const item = items.find((i) => i.id === pick) ?? items[0];
  const groups = [...new Set(items.map((i) => i.group))];
  const example = item && exampleDocs(state).find((e) => e.id === item.id);
  return (
    <section className="compare-panel">
      <div className="compare-head">
        <div>
          <h2><GitCompareArrows size={16} className="inline" /> Compare a request with paperwork</h2>
          <p>Check that what you asked for is what arrived — missing or short items, extras, and price changes. Works offline.</p>
        </div>
        <Button size="sm" variant="ghost" aria-expanded={open} onClick={() => setOpen(!open)}>{open ? "Hide" : "Show"}</Button>
      </div>
      {open && (
        <>
          <label className="compare-select">
            <span>Paperwork</span>
            <select value={item?.id ?? ""} onChange={(e) => setPick(e.target.value)}>
              {groups.map((g) => <optgroup key={g} label={g}>{items.filter((i) => i.group === g).map((i) => <option key={i.id} value={i.id}>{i.label}</option>)}</optgroup>)}
            </select>
          </label>
          {example && <p className="catalog-hint"><strong>Example:</strong> {example.blurb}</p>}
          {item ? <CompareWithRequest key={item.id} doc={item.doc} initialOrderId={item.orderId} /> : <p className="catalog-hint">No paperwork to compare yet. Scan a delivery note or invoice to get started.</p>}
        </>
      )}
    </section>
  );
}
