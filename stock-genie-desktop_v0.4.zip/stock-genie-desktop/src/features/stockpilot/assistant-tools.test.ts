import { describe, expect, it } from "vitest";
import { createPurchaseRequest, initialState, type StoreState } from "./model";
import { createToolRunner } from "./assistant-tools";
import { exampleDocs } from "./compare";

const setup = (role: "Manager" | "Staff", patch: Partial<StoreState> = {}) => {
  let st: StoreState = { ...initialState, ...patch };
  const run = createToolRunner({ get: () => st, set: (s) => (st = s), user: "Tester", role, budget: 5000 });
  return { run, get: () => st, call: (n: string, i: Record<string, unknown>) => JSON.parse(run(n, i)) };
};

describe("assistant tools", () => {
  it("creates a product and clamps an unsafe AI price", () => {
    const t = setup("Manager");
    const r = t.call("create_product", { name: "Sprite Lime", size: "500 ml", category: "Beverages", cost: 0.9, supplier: "coca-cola distribution", price: 0.8 });
    expect(r.created.price).toBeGreaterThan(0.9 * 1.1);
    expect(r.created.supplier).toBe("Coca-Cola Distribution");
    expect(t.call("create_product", { name: "Sprite Lime", size: "500ml", category: "Beverages", cost: 0.9, supplier: "Coca-Cola Distribution" }).error).toContain("already exists");
  });
  it("blocks staff from adding products or changing prices", () => {
    const t = setup("Staff");
    expect(t.call("create_product", { name: "Y", category: "Snacks", cost: 1, supplier: "S" }).error).toContain("manager");
    expect(t.call("update_price", { product_id: "p1", new_price: 2 }).error).toContain("manager");
  });
  it("drafts a custom purchase request, merging lines and rejecting wrong suppliers", () => {
    const t = setup("Manager");
    expect(t.call("create_purchase_draft", { supplier: "Metro Wholesale", lines: [{ product_id: "p1", quantity: 24 }] }).error).toBeDefined();
    const before = t.get().orders.length;
    const ok = t.call("create_purchase_draft", { supplier: "metro wholesale", lines: [{ product_id: "p5", quantity: 24 }, { product_id: "p5", quantity: 24 }] });
    expect(ok.created).toBeDefined();
    expect(t.get().orders).toHaveLength(before + 1);
    expect(t.get().orders[0]!.lines[0]!.quantity).toBe(48);
  });
  it("limits price changes to ±30%", () => {
    const t = setup("Manager");
    expect(t.call("update_price", { product_id: "p1", new_price: 9 }).error).toContain("30%");
    expect(t.call("update_price", { product_id: "p1", new_price: 1.99 }).updated.price).toBe(1.99);
  });
  it("compares a request with paperwork through the assistant", () => {
    const ex = exampleDocs(initialState).find((e) => e.id === "ex-short")!;
    const t = setup("Staff", { scans: [{ ...ex.doc, id: "scan-1", documentType: ex.doc.kind, issuer: ex.doc.issuer, recipient: null, number: ex.doc.number, date: null, dueDate: null, currency: "USD", subtotal: null, tax: null, total: ex.doc.total, summary: "", explanation: null, answer: null, warnings: [], time: "", actor: "T", files: [], checks: [] }] }); // read-only, so staff may use it
    const r = t.call("compare_with_request", { document_id: "scan-1", order_id: ex.orderId });
    expect(r.allGood).toBe(false);
    expect(r.counts.missing).toBe(1);
    expect(r.supplierMessage).toContain("short");
  });
  it("adds new products from an invoice with auto prices, and needs a rate for foreign currency", () => {
    const ex = exampleDocs(initialState).find((e) => e.id === "ex-price")!;
    const rec = (currency: string) => ({ ...ex.doc, id: `s-${currency}`, documentType: "Invoice", issuer: ex.doc.issuer, recipient: null, number: "X", date: null, dueDate: null, currency, subtotal: null, tax: null, total: null, summary: "", explanation: null, answer: null, warnings: [], time: "", actor: "T", files: [], checks: [] });
    const scans = [rec("USD"), rec("BGN")];
    const t = setup("Manager", { scans });
    expect(t.call("apply_document_updates", { document_id: "s-BGN" }).error).toContain("exchange rate");
    const before = t.get().products.length;
    const r = t.call("apply_document_updates", { document_id: "s-USD" });
    expect(r.added).toHaveLength(1);
    expect(r.added[0].price).toBeGreaterThan(r.added[0].cost * 1.15);
    expect(r.repriced).toHaveLength(1);
    expect(t.get().products).toHaveLength(before + 1);
    expect(setup("Staff", { scans }).call("apply_document_updates", { document_id: "latest" }).error).toContain("manager");
  });

  it("can only REQUEST authorizations: managers get a card, nothing changes, staff are refused", () => {
    const cards: unknown[] = [];
    let st: StoreState = createPurchaseRequest(initialState, "Metro Wholesale", [{ productId: "p5", quantity: 24 }], "T", "2026-01-05T10:00:00.000Z");
    const id = st.orders[0]!.id;
    const mk = (role: "Manager" | "Staff") =>
      createToolRunner({ get: () => st, set: (s) => (st = s), user: "T", role, budget: 5000, authorize: (r) => (cards.push(r), { ok: true, title: "card" }) });
    const staff = JSON.parse(mk("Staff")("request_order_approval", { order_ids: [id] }));
    expect(staff.error).toContain("manager");
    const mgr = JSON.parse(mk("Manager")("request_order_approval", { order_ids: [id] }));
    expect(mgr.status).toBe("awaiting_authorization");
    expect(cards).toHaveLength(1);
    expect(st.orders[0]!.status).toBe("Draft");
  });
  it("rings up sales, lists orders and receipts, and files supplier reports on its own", () => {
    const t = setup("Staff");
    const sale = t.call("record_sale", { lines: [{ product_id: "p1", quantity: 2 }], method: "Cash", paid: 100 });
    expect(sale.receipt).toMatch(/^R-/);
    expect(sale.change).toBeGreaterThan(0);
    expect(t.call("record_sale", { lines: [{ product_id: "p1", quantity: 2 }], method: "Cash", paid: 0.5 }).error).toBeDefined();
    expect(t.call("record_sale", { lines: [{ product_id: "p1", quantity: 99999 }], method: "Card" }).error).toContain("in stock");
    expect(t.call("list_receipts", {}).receipts[0].id).toBe(sale.receipt);
    expect(Array.isArray(t.call("list_orders", {}).orders)).toBe(true);
    expect(t.call("get_overview", {}).totals.activeProducts).toBeGreaterThan(0);
  });
  it("opens a screen only when a navigator is available", () => {
    const seen: string[] = [];
    let st: StoreState = initialState;
    const run = createToolRunner({ get: () => st, set: (s) => (st = s), user: "T", role: "Manager", budget: 1, navigate: (s) => seen.push(s) });
    expect(JSON.parse(run("open_screen", { screen: "orders" })).opened).toBe("orders");
    expect(seen).toEqual(["orders"]);
    expect(setup("Manager").call("open_screen", { screen: "orders" }).error).toBeDefined();
  });
});
