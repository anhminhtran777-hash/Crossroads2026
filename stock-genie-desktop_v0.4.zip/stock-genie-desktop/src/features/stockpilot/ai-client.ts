import { bridge } from "./desktop";

/** Thin, typed wrapper around the desktop shell's AI call. The shell holds the key and does the network request. */
export type AiBlock =
  | { type: "text"; text: string }
  | { type: "tool_use"; id: string; name: string; input: Record<string, unknown> }
  | { type: "tool_result"; tool_use_id: string; content: string; is_error?: boolean }
  | { type: "image"; source: { type: "base64"; media_type: string; data: string } }
  | { type: "document"; source: { type: "base64"; media_type: "application/pdf"; data: string } };
export type AiMessage = { role: "user" | "assistant"; content: string | AiBlock[] };
export type AiTool = { name: string; description: string; input_schema: Record<string, unknown> };
export type AiReply =
  | { ok: true; content: AiBlock[]; stopReason: string }
  | { ok: false; error: string; code: string };

export async function askAi(req: {
  system: string;
  messages: AiMessage[];
  tools?: AiTool[];
  maxTokens?: number;
  temperature?: number;
}): Promise<AiReply> {
  const b = bridge();
  if (!b) return { ok: false, code: "no_desktop", error: "AI features are available in the Stock Genie desktop app." };
  if (typeof navigator !== "undefined" && !navigator.onLine)
    return { ok: false, code: "offline", error: "No internet connection — AI features are unavailable. Everything else keeps working offline." };
  const res = await b.ai.request({
    system: req.system,
    messages: req.messages,
    max_tokens: req.maxTokens ?? 1500,
    ...(req.tools?.length ? { tools: req.tools } : {}),
    ...(req.temperature !== undefined ? { temperature: req.temperature } : {}),
  });
  if (!res.ok) return { ok: false, code: res.code ?? "api", error: res.error };
  const data = res.data as { content?: AiBlock[]; stop_reason?: string };
  return { ok: true, content: data.content ?? [], stopReason: data.stop_reason ?? "end_turn" };
}

export const textOf = (blocks: AiBlock[]) =>
  blocks.filter((x): x is Extract<AiBlock, { type: "text" }> => x.type === "text").map((x) => x.text).join("\n").trim();

/**
 * Runs a short tool-use conversation: the model may call tools (executed locally by `run`), then answers.
 * Capped at a few steps so a confused model can never loop.
 */
export async function runAgent(args: {
  system: string;
  messages: AiMessage[];
  tools: AiTool[];
  run: (name: string, input: Record<string, unknown>) => string;
  maxSteps?: number;
  maxTokens?: number;
}): Promise<{ ok: true; text: string } | { ok: false; error: string; code: string }> {
  const msgs = [...args.messages];
  for (let step = 0; step < (args.maxSteps ?? 4); step++) {
    const r = await askAi({ system: args.system, messages: msgs, tools: args.tools, maxTokens: args.maxTokens ?? 1500 });
    if (!r.ok) return r;
    const calls = r.content.filter((x): x is Extract<AiBlock, { type: "tool_use" }> => x.type === "tool_use");
    if (!calls.length || r.stopReason !== "tool_use") return { ok: true, text: textOf(r.content) || "Done." };
    msgs.push({ role: "assistant", content: r.content });
    msgs.push({
      role: "user",
      content: calls.map((c) => {
        try {
          return { type: "tool_result" as const, tool_use_id: c.id, content: args.run(c.name, c.input) };
        } catch (e) {
          return { type: "tool_result" as const, tool_use_id: c.id, content: String(e), is_error: true };
        }
      }),
    });
  }
  return { ok: true, text: "I made the changes above. Let me know if you’d like anything else." };
}
