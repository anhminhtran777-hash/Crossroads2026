import { describe, expect, it } from "vitest";
import { checkout, createPurchaseRequest, initialState, supplierDocuments, type StoreState } from "./model";
import { executeAuthorization, prepareAuthorization } from "./authorizations";

const ctx = { budget: 5000, budgetLeft: 5000 };
const withDraft = (): { state: StoreState; id: string } => {
  const state = createPurchaseRequest(initialState, "Metro Wholesale", [{ productId: "p5", quantity: 24 }], "Tester", "2026-01-05T10:00:00.000Z");
  return { state, id: state.orders[0]!.id };
};

describe("authorizations", () => {
  it("turns a draft into an approval card, and only the app can carry it out", () => {
    const { state, id } = withDraft();
    const prep = prepareAuthorization(state, { kind: "approve_orders", orderIds: [id] }, ctx);
    expect(prep.ok).toBe(true);
    if (!prep.ok) return;
    expect(prep.auth.status).toBe("pending");
    expect(prep.auth.amount).toBeGreaterThan(0);
    // Preparing a card changes nothing.
    expect(state.orders[0]!.status).toBe("Draft");
    const done = executeAuthorization(state, prep.auth.request, "Manager", new Date("2026-01-05T11:00:00.000Z"));
    expect(done.ok).toBe(true);
    expect(done.state.orders.find((o) => o.id === id)?.status).toBe("Approved");
    const docs = supplierDocuments(done.state, id);
    expect(docs.invoice).toBeDefined();
    expect(docs.delivery).toBeDefined();
    expect(done.state.products.find((p) => p.id === "p5")?.stock).toBe(state.products.find((p) => p.id === "p5")?.stock);
  });

  it("refuses requests that make no sense", () => {
    const { state, id } = withDraft();
    expect(prepareAuthorization(state, { kind: "approve_orders", orderIds: ["PO-9999"] }, ctx).ok).toBe(false);
    expect(prepareAuthorization(state, { kind: "approve_orders", orderIds: [] }, ctx).ok).toBe(false);
    expect(prepareAuthorization(state, { kind: "receive_orders", orderIds: [id] }, ctx).ok).toBe(false);
    expect(prepareAuthorization(state, { kind: "set_budget", amount: -5 }, ctx).ok).toBe(false);
    expect(prepareAuthorization(state, { kind: "stock_removal", productId: "p5", quantity: 100000, mode: "remove", reason: "Damaged" }, ctx).ok).toBe(false);
  });

  it("warns when approving would exceed the purchase budget", () => {
    const { state, id } = withDraft();
    const prep = prepareAuthorization(state, { kind: "approve_orders", orderIds: [id] }, { budget: 10, budgetLeft: 10 });
    expect(prep.ok && prep.auth.details.join(" ")).toContain("purchase budget");
  });

  it("receives an approved order into stock, recording missing paperwork first", () => {
    const { state, id } = withDraft();
    const approved = executeAuthorization(state, { kind: "approve_orders", orderIds: [id] }, "Manager").state;
    const before = approved.products.find((p) => p.id === "p5")!.stock;
    const prep = prepareAuthorization(approved, { kind: "receive_orders", orderIds: [id] }, ctx);
    expect(prep.ok).toBe(true);
    const received = executeAuthorization(approved, { kind: "receive_orders", orderIds: [id] }, "Manager");
    expect(received.ok).toBe(true);
    expect(received.state.orders.find((o) => o.id === id)?.status).toBe("Received");
    expect(received.state.products.find((p) => p.id === "p5")?.stock).toBe(before + 24);
    // A second attempt is rejected, not applied twice.
    expect(executeAuthorization(received.state, { kind: "receive_orders", orderIds: [id] }, "Manager").ok).toBe(false);
  });

  it("re-checks at approval time (an order approved elsewhere is not approved twice)", () => {
    const { state, id } = withDraft();
    const once = executeAuthorization(state, { kind: "approve_orders", orderIds: [id] }, "Manager").state;
    const again = executeAuthorization(once, { kind: "approve_orders", orderIds: [id] }, "Manager");
    expect(again.ok).toBe(false);
    expect(again.state).toBe(once);
  });

  it("refunds a sale only through an authorization, returning resellable stock to the shelf", () => {
    const sold = checkout(initialState, [{ productId: "p1", quantity: 2 }], "Card", undefined, "Tester", new Date().toISOString(), "R-1001");
    expect(sold.receipt).toBeDefined();
    const req = { kind: "customer_refund" as const, receiptId: "R-1001", lines: [{ productId: "p1", quantity: 1 }], reason: "Defective item", condition: "Resellable" as const, note: "" };
    const prep = prepareAuthorization(sold.state, req, ctx);
    expect(prep.ok).toBe(true);
    const stockBefore = sold.state.products.find((p) => p.id === "p1")!.stock;
    const done = executeAuthorization(sold.state, req, "Manager");
    expect(done.ok).toBe(true);
    expect(done.state.products.find((p) => p.id === "p1")?.stock).toBe(stockBefore + 1);
    expect((done.state.documents ?? []).some((d) => d.kind === "Refund receipt")).toBe(true);
    // Too many units cannot even become a card.
    expect(prepareAuthorization(sold.state, { ...req, lines: [{ productId: "p1", quantity: 5 }] }, ctx).ok).toBe(false);
  });

  it("writes stock off, archives products and changes the budget", () => {
    const before = initialState.products.find((p) => p.id === "p1")!.stock;
    const off = executeAuthorization(initialState, { kind: "stock_removal", productId: "p1", quantity: 3, mode: "remove", reason: "Damaged" }, "Manager");
    expect(off.ok).toBe(true);
    expect(off.state.products.find((p) => p.id === "p1")?.stock).toBe(before - 3);
    const arch = executeAuthorization(initialState, { kind: "archive_product", productId: "p1" }, "Manager");
    expect(arch.state.products.find((p) => p.id === "p1")?.archived).toBe(true);
    const budget = executeAuthorization(initialState, { kind: "set_budget", amount: 2500 }, "Manager");
    expect(budget.budget).toBe(2500);
    expect(budget.state).toBe(initialState);
  });
});
