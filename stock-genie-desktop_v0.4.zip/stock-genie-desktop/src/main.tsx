import "@fontsource-variable/dm-sans";
import "@fontsource-variable/manrope";
import "./styles.css";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { RouterProvider } from "@tanstack/react-router";
import { getRouter } from "./router";
import { installDiskMirror } from "./features/stockpilot/desktop-storage";

// Restore saved data from the Windows profile folder before anything reads it.
installDiskMirror();

const router = getRouter();

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
);
