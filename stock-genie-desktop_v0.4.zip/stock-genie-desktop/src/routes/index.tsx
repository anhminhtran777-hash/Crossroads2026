import { createFileRoute } from "@tanstack/react-router";
import { Workspace } from "@/features/stockpilot/workspace";
export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Stock Genie" },
      {
        name: "description",
        content:
          "Talk to Stock Genie: the AI runs your store and only asks for your authorization.",
      },
      { property: "og:title", content: "Stock Genie" },
      {
        property: "og:description",
        content: "Your AI store manager. Everything is automated except the approvals.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <Workspace page="Home" />,
});
