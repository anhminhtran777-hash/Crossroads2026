import { createFileRoute, redirect } from "@tanstack/react-router";

// The assistant used to be a separate page; it is now the home screen.
export const Route = createFileRoute("/assistant")({
  beforeLoad: () => {
    throw redirect({ to: "/" });
  },
});
