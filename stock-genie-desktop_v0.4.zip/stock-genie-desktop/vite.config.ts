import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { tanstackRouter } from "@tanstack/router-plugin/vite";
import path from "node:path";

// Production pages get a strict Content-Security-Policy (dev needs inline scripts for hot reload).
// The interface never talks to the network itself; only the desktop shell calls the AI service.
const strictCsp = {
  name: "stockgenie-csp",
  apply: "build" as const,
  transformIndexHtml: () => [
    {
      tag: "meta",
      attrs: {
        "http-equiv": "Content-Security-Policy",
        content:
          "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'",
      },
      injectTo: "head-prepend" as const,
    },
  ],
};

// Plain client-side build: no server, so the output (dist/) loads straight from disk inside Electron.
export default defineConfig({
  base: "./",
  plugins: [
    tanstackRouter({ target: "react", autoCodeSplitting: false }),
    react(),
    tailwindcss(),
    strictCsp,
  ],
  resolve: { alias: { "@": path.resolve(__dirname, "./src") } },
  build: { outDir: "dist", emptyOutDir: true, sourcemap: false },
});
