# Stock Genie — Windows desktop app

An AI-run store manager for small shops. **The home screen is the chat**: you talk to Stock Genie and it does the
work — restocking, pricing, new products, sales, supplier paperwork, issue reports. The only thing it ever waits
for is **your authorization**. Inventory, cashier, orders and documents are still there as manual screens
(sidebar), but you never have to open them.

* **Offline first.** The whole app (inventory, cashier, orders, documents, reports, charts, smart restock
  plan, insights) runs from your PC with no internet. Fonts and the logo are bundled.
* **Only AI needs the internet.** The assistant chat and document scanning call Anthropic's API through the
  desktop shell, using your own API key (Settings → AI & data). Without a key or connection the assistant
  still answers from your own numbers.
* **Your data stays local.** Saved to `%APPDATA%\Stock Genie\stockgenie-data.json` with rolling backups;
  export/import from Settings → AI & data.

## How it works: AI does it, you authorize it

When the app opens, the assistant has already looked after the shop: it drafts restock requests from your sales
pace (switch off under Settings → AI & data) and greets you with a short briefing. Anything that needs your OK
appears as an **Approve / Decline card** in the chat.

**Automatic (no questions asked)** — the assistant uses its tools on its own:

* restock drafts from the smart plan, and custom purchase drafts ("order 48 Pepsi Max from PepsiCo")
* adding products, with automatic pricing from similar items in your own shop (median markup, size adjustment,
  shop-style endings like 1.79; at least 15% over cost, never above similar items; ±30% per price change)
* ringing up sales at the till, listing orders and receipts, showing any screen on request
* reading photos/PDFs of invoices, receipts and delivery notes (**drop or attach them in the chat**), checking
  them against your purchase requests and costs, adding the new products they contain, re-pricing changed costs
* recording the supplier's invoice and delivery note after you approve an order
* filing supplier-issue reports (missing / damaged / wrong item / price mismatch)

**Needs your authorization** (managers only) — the assistant can only *ask*; the app carries it out after you
click Approve, and re-checks everything first:

* approving purchase requests (commits money) — one card for several drafts
* accepting a delivery (puts goods into stock)
* refunding a customer
* writing stock off / returning it to a supplier
* archiving a product
* changing the monthly purchase budget

Staff can use the chat for everything automatic; authorization cards show "A manager has to authorize this" until a
manager signs in. Every AI-made change is written to the activity log with "(AI assistant)" or
"(from scanned document)".

**No internet / no API key:** the chat still opens, briefs you from your own numbers, and understands a few
everyday commands ("create reorder drafts", "approve all the orders", "the delivery arrived"), including the same
approval cards. The full assistant and document reading need the AI connection (Settings → AI & data).

## Build the Windows app

Requires Windows 10/11 and Node.js 20+ (https://nodejs.org).

```bat
npm install
npm run dist          :: creates release\Stock Genie Setup 1.0.0.exe and a portable .exe
```

Other commands:

```bat
npm run electron:dev  :: run with hot reload
npm run electron:start:: build and run without packaging
npm run test          :: unit tests
npm run typecheck
```

The logo is `src/assets/stock-genie-logo.png` (icon only; the full logo with wordmark is `stock-genie-logo-full.png`). Replace
`build/icon.png` (512×512) for the app icon.

## Architecture

* `src/` — React + TypeScript interface (TanStack Router, hash history so it loads from disk).
* `src/features/stockpilot/model.ts` — pure inventory logic (unchanged behaviour).
* `insights.ts` — offline smart restocking, revenue and retention analysis.
* `scan-checks.ts` — offline cross-checks of scanned documents against your orders and costs.
* `assistant.tsx` — the home chat; `assistant-tools.ts` — everything the AI can do; `authorizations.ts` — the
  approval cards and how they are carried out; `briefing.ts` — the opening report; `chat-store.ts` — the conversation
  (kept while you move between screens); `ai-client.ts`, `scan.tsx` — the only code that calls the AI.
* `electron/main.cjs` — window, file storage + backups, encrypted key, AI requests, network lockdown.
* `electron/preload.cjs` — the small API the interface may use.

Security notes: renderer is sandboxed (no Node, context isolation), a strict Content-Security-Policy is
injected into production builds, and any non-local network request from the interface is blocked.
The demo sign-in accounts (manager/staff) are placeholders, not real security — replace them before
real multi-user use.
