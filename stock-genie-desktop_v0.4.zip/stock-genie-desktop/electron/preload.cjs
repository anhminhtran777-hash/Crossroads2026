/* Exposes a small, explicit API to the interface. No Node access, no raw IPC. */
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("stockGenie", {
  isDesktop: true,
  platform: process.platform,
  storage: {
    loadSync: () => ipcRenderer.sendSync("storage:load"),
    save: (snapshot) => ipcRenderer.invoke("storage:save", snapshot),
    saveSync: (snapshot) => ipcRenderer.sendSync("storage:saveSync", snapshot),
    exportTo: () => ipcRenderer.invoke("storage:export"),
    importFrom: () => ipcRenderer.invoke("storage:import"),
  },
  ai: {
    status: () => ipcRenderer.invoke("ai:status"),
    setKey: (key) => ipcRenderer.invoke("ai:setKey", key),
    clearKey: () => ipcRenderer.invoke("ai:clearKey"),
    setModel: (model) => ipcRenderer.invoke("ai:setModel", model),
    request: (payload) => ipcRenderer.invoke("ai:request", payload),
  },
  app: {
    info: () => ipcRenderer.invoke("app:info"),
    openDataFolder: () => ipcRenderer.invoke("app:openDataFolder"),
  },
  log: (level, message) => ipcRenderer.send("log", level, message),
});
