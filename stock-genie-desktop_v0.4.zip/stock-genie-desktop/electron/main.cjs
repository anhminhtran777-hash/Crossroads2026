/* Stock Genie — Windows desktop shell (Electron main process).
 *
 * Responsibilities
 *  - Open the bundled interface from disk, so the app works with no internet.
 *  - Keep the store's data in a JSON file in the user's profile, with rolling backups.
 *  - Be the ONLY part of the app that talks to the network, and only for the AI features.
 *    The Anthropic API key is stored encrypted (Windows DPAPI) and never reaches the interface code.
 */
const { app, BrowserWindow, Menu, ipcMain, dialog, shell, safeStorage, session } = require("electron");
const fs = require("node:fs");
const path = require("node:path");

const DEV_URL = process.env.STOCKGENIE_DEV_URL || "";
const API_URL = "https://api.anthropic.com/v1/messages";
const API_VERSION = "2023-06-01";
const DEFAULT_MODEL = "claude-sonnet-5-5";
const MAX_REQUEST_BYTES = 40 * 1024 * 1024;

if (!app.requestSingleInstanceLock()) {
  app.quit();
}

let win = null;
const dir = (...p) => path.join(app.getPath("userData"), ...p);
const DATA_FILE = () => dir("stockgenie-data.json");
const BACKUP_DIR = () => dir("backups");
const AI_FILE = () => dir("ai-settings.json");
const LOG_FILE = () => dir("logs", "app.log");

/* ------------------------------- logging -------------------------------- */
function log(level, message) {
  try {
    fs.mkdirSync(dir("logs"), { recursive: true });
    const file = LOG_FILE();
    if (fs.existsSync(file) && fs.statSync(file).size > 1_000_000) fs.renameSync(file, file + ".old");
    fs.appendFileSync(file, `${new Date().toISOString()} [${level}] ${String(message).slice(0, 4000)}\n`);
  } catch {
    /* logging must never crash the app */
  }
}

/* ------------------------------- storage -------------------------------- */
function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}
function atomicWrite(file, text) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + ".tmp";
  fs.writeFileSync(tmp, text);
  fs.renameSync(tmp, file);
}
let lastBackup = 0;
function backupNow(force) {
  try {
    const file = DATA_FILE();
    if (!fs.existsSync(file)) return;
    if (!force && Date.now() - lastBackup < 3 * 3600 * 1000) return;
    fs.mkdirSync(BACKUP_DIR(), { recursive: true });
    const stamp = new Date().toISOString().replace(/[:T]/g, "-").slice(0, 19);
    fs.copyFileSync(file, path.join(BACKUP_DIR(), `stockgenie-${stamp}.json`));
    lastBackup = Date.now();
    const old = fs.readdirSync(BACKUP_DIR()).filter((f) => f.endsWith(".json")).sort().reverse().slice(20);
    for (const f of old) fs.rmSync(path.join(BACKUP_DIR(), f), { force: true });
  } catch (e) {
    log("warn", `backup failed: ${e}`);
  }
}
function validSnapshot(x) {
  return !!x && typeof x === "object" && !Array.isArray(x) && Object.entries(x).every(([k, v]) => k.startsWith("stockgenie:") && typeof v === "string");
}
function saveSnapshot(snapshot) {
  if (!validSnapshot(snapshot)) return false;
  try {
    backupNow(false);
    atomicWrite(DATA_FILE(), JSON.stringify(snapshot));
    return true;
  } catch (e) {
    log("error", `save failed: ${e}`);
    return false;
  }
}

/* --------------------------------- AI ----------------------------------- */
function aiSettings() {
  const raw = readJson(AI_FILE(), {});
  return { model: typeof raw.model === "string" ? raw.model : DEFAULT_MODEL, key: typeof raw.key === "string" ? raw.key : "" };
}
function getApiKey() {
  const { key } = aiSettings();
  if (!key) return "";
  try {
    return safeStorage.decryptString(Buffer.from(key, "base64"));
  } catch {
    return "";
  }
}
const modelOk = (m) => typeof m === "string" && /^claude-[a-z0-9.\-]{2,60}$/.test(m);

async function aiRequest(payload) {
  const key = getApiKey();
  if (!key) return { ok: false, code: "no_key", error: "Add your Anthropic API key in Settings → AI & data." };
  if (!payload || typeof payload !== "object" || !Array.isArray(payload.messages)) return { ok: false, code: "bad_request", error: "Invalid request." };
  const body = {
    model: modelOk(payload.model) ? payload.model : aiSettings().model,
    max_tokens: Math.min(Math.max(Number(payload.max_tokens) || 1024, 64), 8192),
    messages: payload.messages,
  };
  if (typeof payload.system === "string") body.system = payload.system.slice(0, 120_000);
  if (Array.isArray(payload.tools) && payload.tools.length) body.tools = payload.tools;
  if (typeof payload.temperature === "number") body.temperature = Math.min(Math.max(payload.temperature, 0), 1);
  const text = JSON.stringify(body);
  if (Buffer.byteLength(text) > MAX_REQUEST_BYTES) return { ok: false, code: "too_large", error: "The attached files are too large. Try fewer or smaller pages." };
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 150_000);
  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": API_VERSION },
      body: text,
      signal: ctl.signal,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = data?.error?.message || `The AI service returned an error (${res.status}).`;
      const code = res.status === 401 || res.status === 403 ? "auth" : res.status === 429 ? "rate_limit" : res.status === 529 ? "busy" : "api";
      log("warn", `ai ${res.status}: ${msg}`);
      return { ok: false, code, error: code === "auth" ? "The API key was rejected. Check it in Settings → AI & data." : msg };
    }
    return { ok: true, data };
  } catch (e) {
    const aborted = e && e.name === "AbortError";
    log("warn", `ai network: ${e}`);
    return { ok: false, code: aborted ? "timeout" : "offline", error: aborted ? "The AI took too long to answer. Try again." : "No internet connection — AI features are unavailable. Everything else keeps working offline." };
  } finally {
    clearTimeout(timer);
  }
}

/* ------------------------------ IPC wiring ------------------------------ */
function registerIpc() {
  ipcMain.on("storage:load", (e) => {
    let data = readJson(DATA_FILE(), null);
    if (!validSnapshot(data)) {
      // Fall back to the newest backup if the main file is missing or damaged.
      data = null;
      try {
        const newest = fs.readdirSync(BACKUP_DIR()).filter((f) => f.endsWith(".json")).sort().reverse()[0];
        if (newest) data = readJson(path.join(BACKUP_DIR(), newest), null);
      } catch {}
      if (!validSnapshot(data)) data = null;
    }
    e.returnValue = data;
  });
  ipcMain.on("storage:saveSync", (e, snapshot) => {
    e.returnValue = saveSnapshot(snapshot);
  });
  ipcMain.handle("storage:save", (_e, snapshot) => saveSnapshot(snapshot));
  ipcMain.handle("storage:export", async () => {
    const r = await dialog.showSaveDialog(win, {
      title: "Export Stock Genie data",
      defaultPath: `stock-genie-backup-${new Date().toISOString().slice(0, 10)}.json`,
      filters: [{ name: "Stock Genie backup", extensions: ["json"] }],
    });
    if (r.canceled || !r.filePath) return { ok: false, canceled: true };
    try {
      fs.copyFileSync(DATA_FILE(), r.filePath);
      return { ok: true, path: r.filePath };
    } catch (e) {
      return { ok: false, error: String(e) };
    }
  });
  ipcMain.handle("storage:import", async () => {
    const r = await dialog.showOpenDialog(win, { title: "Import Stock Genie backup", properties: ["openFile"], filters: [{ name: "Stock Genie backup", extensions: ["json"] }] });
    if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
    const data = readJson(r.filePaths[0], null);
    if (!validSnapshot(data)) return { ok: false, error: "That file is not a Stock Genie backup." };
    backupNow(true);
    atomicWrite(DATA_FILE(), JSON.stringify(data));
    app.relaunch();
    app.exit(0);
    return { ok: true };
  });
  ipcMain.handle("ai:status", () => {
    const s = aiSettings();
    return { hasKey: !!s.key, model: s.model, encryptionAvailable: safeStorage.isEncryptionAvailable() };
  });
  ipcMain.handle("ai:setKey", (_e, key) => {
    const k = String(key || "").trim();
    if (!/^sk-ant-[A-Za-z0-9_\-]{20,}$/.test(k)) return { ok: false, error: "That doesn't look like an Anthropic API key (it starts with sk-ant-)." };
    if (!safeStorage.isEncryptionAvailable()) return { ok: false, error: "Secure storage is unavailable on this PC, so the key was not saved." };
    atomicWrite(AI_FILE(), JSON.stringify({ ...aiSettings(), key: safeStorage.encryptString(k).toString("base64") }));
    return { ok: true };
  });
  ipcMain.handle("ai:clearKey", () => {
    atomicWrite(AI_FILE(), JSON.stringify({ ...aiSettings(), key: "" }));
    return { ok: true };
  });
  ipcMain.handle("ai:setModel", (_e, model) => {
    if (!modelOk(model)) return { ok: false, error: "Invalid model name." };
    atomicWrite(AI_FILE(), JSON.stringify({ ...aiSettings(), model }));
    return { ok: true };
  });
  ipcMain.handle("ai:request", (_e, payload) => aiRequest(payload));
  ipcMain.on("log", (_e, level, message) => log(String(level).slice(0, 10), message));
  ipcMain.handle("app:info", () => ({ version: app.getVersion(), dataFolder: app.getPath("userData"), electron: process.versions.electron }));
  ipcMain.handle("app:openDataFolder", () => shell.openPath(app.getPath("userData")));
}

/* -------------------------------- window -------------------------------- */
function createWindow() {
  win = new BrowserWindow({
    width: 1480,
    height: 920,
    minWidth: 1100,
    minHeight: 700,
    show: false,
    backgroundColor: "#f7f5ef",
    title: "Stock Genie",
    icon: path.join(__dirname, "..", "build", "icon.png"),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
      devTools: !app.isPackaged,
    },
  });
  win.once("ready-to-show", () => win.show());
  win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  win.webContents.on("will-navigate", (e, url) => {
    if (!url.startsWith("file://") && !(DEV_URL && url.startsWith(DEV_URL))) e.preventDefault();
  });
  win.webContents.on("render-process-gone", (_e, d) => log("error", `renderer gone: ${d.reason}`));
  win.webContents.on("did-fail-load", (_e, code, desc) => log("error", `load failed: ${code} ${desc}`));
  if (DEV_URL) win.loadURL(DEV_URL);
  else win.loadFile(path.join(__dirname, "..", "dist", "index.html"));
  win.on("closed", () => (win = null));
}

app.on("second-instance", () => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.focus();
  }
});

app.whenReady().then(() => {
  registerIpc();
  backupNow(true);
  // The interface itself may only load local files; all internet access goes through the AI handler above.
  session.defaultSession.webRequest.onBeforeRequest((details, cb) => {
    const u = details.url;
    const local = u.startsWith("file://") || u.startsWith("devtools://") || u.startsWith("data:") || u.startsWith("blob:") || u.startsWith("chrome-extension://") || (DEV_URL && (u.startsWith(DEV_URL) || u.startsWith("ws://localhost")));
    cb({ cancel: !local });
  });
  session.defaultSession.setPermissionRequestHandler((_wc, _perm, cb) => cb(false));
  const menu = Menu.buildFromTemplate([
    { label: "Edit", submenu: [{ role: "undo" }, { role: "redo" }, { type: "separator" }, { role: "cut" }, { role: "copy" }, { role: "paste" }, { role: "selectAll" }] },
    { label: "View", submenu: [{ role: "resetZoom" }, { role: "zoomIn" }, { role: "zoomOut" }, { type: "separator" }, { role: "togglefullscreen" }] },
  ]);
  Menu.setApplicationMenu(menu);
  createWindow();
});

app.on("window-all-closed", () => app.quit());
