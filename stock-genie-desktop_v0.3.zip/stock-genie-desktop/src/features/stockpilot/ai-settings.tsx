import { useEffect, useState } from "react";
import { Check, FolderOpen, Download, Upload, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { bridge, useAiStatus, useOnline } from "./desktop";
import { askAi } from "./ai-client";
import { loadPrefs, savePrefs } from "./accounts";

const presets = [
  { id: "claude-sonnet-5-5", label: "Claude Sonnet 5.5 — balanced (recommended)" },
  { id: "claude-haiku-5-5", label: "Claude Haiku 5.5 — fastest and cheapest" },
  { id: "claude-opus-5-5", label: "Claude Opus 5.5 — most capable" },
];

/** Settings → AI & data: API key, model, automatic restocking, backups. */
export function AiSettings() {
  const b = bridge();
  const online = useOnline();
  const [tick, setTick] = useState(0);
  const status = useAiStatus(tick);
  const [key, setKey] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [auto, setAuto] = useState(() => Boolean((loadPrefs()["extra"] as Record<string, unknown> | undefined)?.["autoDraft"]));
  const [info, setInfo] = useState<{ version: string; dataFolder: string } | null>(null);
  useEffect(() => {
    void b?.app.info().then(setInfo);
  }, [b]);

  const saveKey = async () => {
    if (!b) return;
    setBusy(true);
    const r = await b.ai.setKey(key);
    setBusy(false);
    if (r.ok) {
      setKey("");
      setTick((n) => n + 1);
      setMsg({ ok: true, text: "Key saved securely on this PC." });
    } else setMsg({ ok: false, text: r.error ?? "Could not save the key." });
  };
  const test = async () => {
    setBusy(true);
    setMsg(null);
    const r = await askAi({ system: "Reply with the single word OK.", messages: [{ role: "user", content: "ping" }], maxTokens: 16 });
    setBusy(false);
    setMsg(r.ok ? { ok: true, text: "Connected — the AI is ready." } : { ok: false, text: r.error });
  };
  const setAutoDraft = (v: boolean) => {
    setAuto(v);
    const extra = (loadPrefs()["extra"] as Record<string, unknown> | undefined) ?? {};
    savePrefs({ extra: { ...extra, autoDraft: v } });
  };
  const known = presets.some((p) => p.id === status?.model);

  if (!b)
    return (
      <div>
        <h2>AI &amp; data</h2>
        <p className="text-sm text-muted-foreground">AI features and backups are available in the Stock Genie desktop app for Windows.</p>
      </div>
    );

  return (
    <div className="product-form">
      <h2>AI &amp; data</h2>
      <fieldset className="grid gap-3 rounded-md border border-border p-4">
        <legend className="px-1 text-sm font-medium">AI assistant &amp; document scanning</legend>
        <p className="text-sm text-muted-foreground">
          Stock Genie works fully offline. Only the AI assistant and document scanning use the internet, through your own Anthropic API key
          {status?.hasKey ? " (saved)" : " (not set)"}. {online ? "" : "You are offline right now."}
        </p>
        <label>
          Anthropic API key
          <input type="password" autoComplete="off" value={key} onChange={(e) => setKey(e.target.value)} placeholder={status?.hasKey ? "•••••••• saved — paste a new key to replace it" : "sk-ant-…"} />
        </label>
        <div className="flex flex-wrap gap-2">
          <Button type="button" onClick={saveKey} disabled={busy || !key.trim()}>Save key</Button>
          <Button type="button" variant="outline" onClick={test} disabled={busy || !status?.hasKey || !online}>Test connection</Button>
          <Button type="button" variant="outline" disabled={busy || !status?.hasKey} onClick={async () => { await b.ai.clearKey(); setTick((n) => n + 1); setMsg({ ok: true, text: "Key removed." }); }}>Remove key</Button>
        </div>
        {msg && <p className={`${msg.ok ? "positive" : "negative"} text-sm`} role="status">{msg.ok && <Check size={14} className="inline" />} {msg.text}</p>}
        <label>
          Model
          <select
            value={known ? status?.model : "custom"}
            onChange={async (e) => {
              if (e.target.value !== "custom") {
                await b.ai.setModel(e.target.value);
                setTick((n) => n + 1);
              }
            }}
          >
            {presets.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
            {!known && <option value="custom">{status?.model}</option>}
          </select>
        </label>
        <p className="settings-privacy"><ShieldCheck size={15} /> The key is encrypted with Windows and never shown to the app’s screens. The assistant sends a short summary of your stock and sales; scanning sends only the pages you choose.</p>
      </fieldset>
      <fieldset className="grid gap-3 rounded-md border border-border p-4">
        <legend className="px-1 text-sm font-medium">Restocking</legend>
        <div className="settings-check">
          <label>
            <input type="checkbox" checked={auto} onChange={(e) => setAutoDraft(e.target.checked)} />
            <span>Automatically draft restock orders for low stock<small className="block text-muted-foreground">Works offline. Drafts are sized to about two weeks of sales, grouped by supplier, kept within your budget, and always wait for a person to approve them.</small></span>
          </label>
        </div>
      </fieldset>
      <fieldset className="grid gap-3 rounded-md border border-border p-4">
        <legend className="px-1 text-sm font-medium">Your data</legend>
        <p className="text-sm text-muted-foreground">Everything is saved on this computer{info ? ` (${info.dataFolder})` : ""}, with automatic backups. Version {info?.version ?? "…"}.</p>
        <div className="flex flex-wrap gap-2">
          <Button type="button" variant="outline" onClick={async () => { const r = await b.storage.exportTo(); setMsg(r.ok ? { ok: true, text: `Backup saved to ${r.path}` } : r.canceled ? null : { ok: false, text: r.error ?? "Export failed." }); }}><Download /> Export backup</Button>
          <Button type="button" variant="outline" onClick={async () => { if (window.confirm("Replace all current data with the backup file? The app will restart. A safety copy of the current data is kept.")) { const r = await b.storage.importFrom(); if (!r.ok && !r.canceled) setMsg({ ok: false, text: r.error ?? "Import failed." }); } }}><Upload /> Import backup</Button>
          <Button type="button" variant="outline" onClick={() => void b.app.openDataFolder()}><FolderOpen /> Open data folder</Button>
        </div>
      </fieldset>
    </div>
  );
}
