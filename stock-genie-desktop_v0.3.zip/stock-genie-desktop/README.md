# Stock Genie — Windows desktop app

Inventory, cashier, purchase orders and documents for small stores, plus an AI assistant that
helps with restocking, revenue and keeping customers, and reads invoices, receipts and delivery notes.

* **Offline first.** The whole app (inventory, cashier, orders, documents, reports, charts, smart restock
  plan, insights) runs from your PC with no internet. Fonts and the logo are bundled.
* **Only AI needs the internet.** The assistant chat and document scanning call Anthropic's API through the
  desktop shell, using your own API key (Settings → AI & data). Without a key or connection the assistant
  still answers from your own numbers.
* **Your data stays local.** Saved to `%APPDATA%\Stock Genie\stockgenie-data.json` with rolling backups;
  export/import from Settings → AI & data.

## What the AI can do

* **Assistant (chat):** answers from your live numbers and can *act*: create restock drafts, draft a custom
  purchase request ("order 48 Pepsi Max from PepsiCo"), add new products, and change a price on request.
  Adding products and changing prices is manager-only. It can never approve, receive, pay for or delete anything.
* **Paperwork from chat:** ask "check my latest delivery against its request" and the assistant compares it
  (missing / short / extra / re-priced items, plus a supplier message). With a manager's go-ahead it can also add
  the new products found on an invoice (auto-priced) and re-price changed supplier costs. Foreign-currency
  documents need an exchange rate first; stock is never touched.
* **Automatic pricing:** new products are priced from similar items in your own shop (median markup, size
  adjustment, shop-style endings like 1.79). Any price the AI proposes is clamped to safe limits (at least 15%
  over cost, no higher than what similar items sell for). Price changes are limited to ±30% at a time.
* **Scanning:** summarize / explain / extract invoices, receipts and delivery notes. New products found on an
  invoice can be added in one click (editable price); changed supplier costs can update cost and price.
* **Request vs paperwork (Documents tab):** compares a purchase request with a delivery note or invoice and
  lists missing, short, extra and re-priced items, with a ready-to-send message to the supplier. Three
  built-in examples work offline.

Every AI-made change is written to the activity log with "(AI assistant)" or "(from scanned document)".

## Build the Windows app

Requires Windows 10/11 and Node.js 20+ (https://nodejs.org).

```bat
npm install
npm run dist          :: creates release\Stock Genie Setup 1.0.0.exe and a portable .exe
```

Other commands:

```bat
npm run electron:dev  :: run with hot reload
npm run electron:start:: build and run without packaging
npm run test          :: unit tests
npm run typecheck
```

The logo is `src/assets/stock-genie-logo.png` (icon only; the full logo with wordmark is `stock-genie-logo-full.png`). Replace
`build/icon.png` (512×512) for the app icon.

## Architecture

* `src/` — React + TypeScript interface (TanStack Router, hash history so it loads from disk).
* `src/features/stockpilot/model.ts` — pure inventory logic (unchanged behaviour).
* `insights.ts` — offline smart restocking, revenue and retention analysis.
* `scan-checks.ts` — offline cross-checks of scanned documents against your orders and costs.
* `ai-client.ts`, `assistant.tsx`, `scan.tsx` — the only code that uses AI.
* `electron/main.cjs` — window, file storage + backups, encrypted key, AI requests, network lockdown.
* `electron/preload.cjs` — the small API the interface may use.

Security notes: renderer is sandboxed (no Node, context isolation), a strict Content-Security-Policy is
injected into production builds, and any non-local network request from the interface is blocked.
The demo sign-in accounts (manager/staff) are placeholders, not real security — replace them before
real multi-user use.
